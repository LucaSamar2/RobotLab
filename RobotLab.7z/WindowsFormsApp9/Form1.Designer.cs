namespace WindowsFormsApp9
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Arduino = new MetroFramework.Controls.MetroButton();
            this.ControlloX = new MetroFramework.Controls.MetroButton();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tool = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Esecuzione = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel27 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel28 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel29 = new MetroFramework.Controls.MetroLabel();
            this.metroButton32 = new MetroFramework.Controls.MetroButton();
            this.metroButton33 = new MetroFramework.Controls.MetroButton();
            this.metroButton34 = new MetroFramework.Controls.MetroButton();
            this.metroButton38 = new MetroFramework.Controls.MetroButton();
            this.metroButton39 = new MetroFramework.Controls.MetroButton();
            this.metroButton40 = new MetroFramework.Controls.MetroButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.Impostazioni = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel18 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel19 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel20 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel21 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel22 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel23 = new MetroFramework.Controls.MetroLabel();
            this.metroButton11 = new MetroFramework.Controls.MetroButton();
            this.metroButton18 = new MetroFramework.Controls.MetroButton();
            this.metroButton19 = new MetroFramework.Controls.MetroButton();
            this.metroButton20 = new MetroFramework.Controls.MetroButton();
            this.metroButton21 = new MetroFramework.Controls.MetroButton();
            this.metroButton22 = new MetroFramework.Controls.MetroButton();
            this.metroButton23 = new MetroFramework.Controls.MetroButton();
            this.metroButton24 = new MetroFramework.Controls.MetroButton();
            this.metroButton25 = new MetroFramework.Controls.MetroButton();
            this.metroButton26 = new MetroFramework.Controls.MetroButton();
            this.metroButton27 = new MetroFramework.Controls.MetroButton();
            this.metroButton28 = new MetroFramework.Controls.MetroButton();
            this.label1 = new System.Windows.Forms.Label();
            this.metroButton10 = new MetroFramework.Controls.MetroButton();
            this.metroButton12 = new MetroFramework.Controls.MetroButton();
            this.metroButton13 = new MetroFramework.Controls.MetroButton();
            this.metroButton14 = new MetroFramework.Controls.MetroButton();
            this.metroButton15 = new MetroFramework.Controls.MetroButton();
            this.metroButton16 = new MetroFramework.Controls.MetroButton();
            this.metroButton17 = new MetroFramework.Controls.MetroButton();
            this.metroButton29 = new MetroFramework.Controls.MetroButton();
            this.metroButton3 = new MetroFramework.Controls.MetroButton();
            this.metroButton30 = new MetroFramework.Controls.MetroButton();
            this.metroButton31 = new MetroFramework.Controls.MetroButton();
            this.metroButton35 = new MetroFramework.Controls.MetroButton();
            this.metroButton36 = new MetroFramework.Controls.MetroButton();
            this.metroButton37 = new MetroFramework.Controls.MetroButton();
            this.metroButton4 = new MetroFramework.Controls.MetroButton();
            this.metroButton41 = new MetroFramework.Controls.MetroButton();
            this.metroButton42 = new MetroFramework.Controls.MetroButton();
            this.metroButton43 = new MetroFramework.Controls.MetroButton();
            this.metroButton44 = new MetroFramework.Controls.MetroButton();
            this.metroButton45 = new MetroFramework.Controls.MetroButton();
            this.metroButton46 = new MetroFramework.Controls.MetroButton();
            this.metroButton5 = new MetroFramework.Controls.MetroButton();
            this.metroButton6 = new MetroFramework.Controls.MetroButton();
            this.metroButton7 = new MetroFramework.Controls.MetroButton();
            this.metroButton8 = new MetroFramework.Controls.MetroButton();
            this.metroButton9 = new MetroFramework.Controls.MetroButton();
            this.metroCheckBox1 = new MetroFramework.Controls.MetroCheckBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel17 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel24 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel25 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel26 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel30 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroProgressBar1 = new MetroFramework.Controls.MetroProgressBar();
            this.metroTextBox1 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox10 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox11 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox2 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox3 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox4 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox5 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox6 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox7 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox8 = new MetroFramework.Controls.MetroTextBox();
            this.metroTextBox9 = new MetroFramework.Controls.MetroTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.Programma2 = new MetroFramework.Controls.MetroTabPage();
            this.RobotEnabled = new MetroFramework.Controls.MetroToggle();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.elementHost2 = new System.Windows.Forms.Integration.ElementHost();
            this.userControl11 = new WindowsFormsApp9.UserControl1();
            this.Tabprincipale = new MetroFramework.Controls.MetroTabControl();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.metroTextBox12 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.Esecuzione.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.Impostazioni.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.Programma2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.Tabprincipale.SuspendLayout();
            this.SuspendLayout();
            // 
            // Arduino
            // 
            this.Arduino.Location = new System.Drawing.Point(428, 19);
            this.Arduino.Name = "Arduino";
            this.Arduino.Size = new System.Drawing.Size(179, 23);
            this.Arduino.TabIndex = 33;
            this.Arduino.Text = "Crea Programma Per Arduino";
            this.Arduino.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Arduino.UseSelectable = true;
            this.Arduino.Click += new System.EventHandler(this.Arduino_Click);
            // 
            // ControlloX
            // 
            this.ControlloX.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ControlloX.BackgroundImage")));
            this.ControlloX.Location = new System.Drawing.Point(29, 26);
            this.ControlloX.Name = "ControlloX";
            this.ControlloX.Size = new System.Drawing.Size(33, 33);
            this.ControlloX.TabIndex = 8;
            this.ControlloX.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.ControlloX.UseSelectable = true;
            this.ControlloX.Click += new System.EventHandler(this.metroButton11_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7,
            this.Column8,
            this.Tool});
            this.dataGridView1.Location = new System.Drawing.Point(18, 309);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 75;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dataGridView1.Size = new System.Drawing.Size(589, 465);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_RowHeaderMouseDoubleClick);
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Column1.HeaderText = "X";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column1.Width = 60;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Column2.HeaderText = "Y";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column2.Width = 60;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Z";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 60;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "A";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 60;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "B";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 60;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "C";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 60;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Vel.";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Width = 50;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Acc.";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Width = 50;
            // 
            // Tool
            // 
            this.Tool.HeaderText = "Tool";
            this.Tool.Name = "Tool";
            this.Tool.ReadOnly = true;
            this.Tool.Width = 50;
            // 
            // Esecuzione
            // 
            this.Esecuzione.Controls.Add(this.metroLabel27);
            this.Esecuzione.Controls.Add(this.metroLabel28);
            this.Esecuzione.Controls.Add(this.metroLabel29);
            this.Esecuzione.Controls.Add(this.metroButton32);
            this.Esecuzione.Controls.Add(this.metroButton33);
            this.Esecuzione.Controls.Add(this.metroButton34);
            this.Esecuzione.Controls.Add(this.metroButton38);
            this.Esecuzione.Controls.Add(this.metroButton39);
            this.Esecuzione.Controls.Add(this.metroButton40);
            this.Esecuzione.HorizontalScrollbarBarColor = true;
            this.Esecuzione.HorizontalScrollbarHighlightOnWheel = false;
            this.Esecuzione.HorizontalScrollbarSize = 10;
            this.Esecuzione.Location = new System.Drawing.Point(4, 38);
            this.Esecuzione.Name = "Esecuzione";
            this.Esecuzione.Size = new System.Drawing.Size(338, 196);
            this.Esecuzione.TabIndex = 1;
            this.Esecuzione.Text = "Tool                 ";
            this.Esecuzione.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Esecuzione.VerticalScrollbarBarColor = true;
            this.Esecuzione.VerticalScrollbarHighlightOnWheel = false;
            this.Esecuzione.VerticalScrollbarSize = 10;
            // 
            // metroLabel27
            // 
            this.metroLabel27.AutoSize = true;
            this.metroLabel27.Location = new System.Drawing.Point(123, 123);
            this.metroLabel27.Name = "metroLabel27";
            this.metroLabel27.Size = new System.Drawing.Size(54, 19);
            this.metroLabel27.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel27.TabIndex = 57;
            this.metroLabel27.Text = "Normal";
            this.metroLabel27.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel28
            // 
            this.metroLabel28.AutoSize = true;
            this.metroLabel28.Location = new System.Drawing.Point(129, 66);
            this.metroLabel28.Name = "metroLabel28";
            this.metroLabel28.Size = new System.Drawing.Size(48, 19);
            this.metroLabel28.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel28.TabIndex = 56;
            this.metroLabel28.Text = "Sliding";
            this.metroLabel28.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel29
            // 
            this.metroLabel29.AutoSize = true;
            this.metroLabel29.Location = new System.Drawing.Point(123, 4);
            this.metroLabel29.Name = "metroLabel29";
            this.metroLabel29.Size = new System.Drawing.Size(67, 19);
            this.metroLabel29.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel29.TabIndex = 55;
            this.metroLabel29.Text = "Approach";
            this.metroLabel29.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroLabel29.Click += new System.EventHandler(this.metroLabel29_Click);
            // 
            // metroButton32
            // 
            this.metroButton32.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton32.BackgroundImage")));
            this.metroButton32.Location = new System.Drawing.Point(110, 145);
            this.metroButton32.Name = "metroButton32";
            this.metroButton32.Size = new System.Drawing.Size(33, 33);
            this.metroButton32.TabIndex = 51;
            this.metroButton32.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton32.UseSelectable = true;
            this.metroButton32.Click += new System.EventHandler(this.metroButton32_Click);
            // 
            // metroButton33
            // 
            this.metroButton33.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton33.BackgroundImage")));
            this.metroButton33.Location = new System.Drawing.Point(110, 88);
            this.metroButton33.Name = "metroButton33";
            this.metroButton33.Size = new System.Drawing.Size(33, 33);
            this.metroButton33.TabIndex = 50;
            this.metroButton33.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton33.UseSelectable = true;
            this.metroButton33.Click += new System.EventHandler(this.metroButton33_Click);
            // 
            // metroButton34
            // 
            this.metroButton34.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton34.BackgroundImage")));
            this.metroButton34.Location = new System.Drawing.Point(110, 26);
            this.metroButton34.Name = "metroButton34";
            this.metroButton34.Size = new System.Drawing.Size(33, 33);
            this.metroButton34.TabIndex = 49;
            this.metroButton34.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton34.UseSelectable = true;
            this.metroButton34.Click += new System.EventHandler(this.metroButton34_Click);
            // 
            // metroButton38
            // 
            this.metroButton38.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton38.BackgroundImage")));
            this.metroButton38.Location = new System.Drawing.Point(161, 145);
            this.metroButton38.Name = "metroButton38";
            this.metroButton38.Size = new System.Drawing.Size(33, 33);
            this.metroButton38.TabIndex = 45;
            this.metroButton38.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton38.UseSelectable = true;
            this.metroButton38.Click += new System.EventHandler(this.metroButton38_Click_1);
            // 
            // metroButton39
            // 
            this.metroButton39.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton39.BackgroundImage")));
            this.metroButton39.Location = new System.Drawing.Point(161, 88);
            this.metroButton39.Name = "metroButton39";
            this.metroButton39.Size = new System.Drawing.Size(33, 33);
            this.metroButton39.TabIndex = 44;
            this.metroButton39.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton39.UseSelectable = true;
            this.metroButton39.Click += new System.EventHandler(this.metroButton39_Click_1);
            // 
            // metroButton40
            // 
            this.metroButton40.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton40.BackgroundImage")));
            this.metroButton40.Location = new System.Drawing.Point(161, 26);
            this.metroButton40.Name = "metroButton40";
            this.metroButton40.Size = new System.Drawing.Size(33, 33);
            this.metroButton40.TabIndex = 43;
            this.metroButton40.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton40.UseSelectable = true;
            this.metroButton40.Click += new System.EventHandler(this.metroButton40_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.metroButton2);
            this.groupBox1.Controls.Add(this.metroButton1);
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.groupBox1.Location = new System.Drawing.Point(953, 46);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(156, 111);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Aggiungi";
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(42, 67);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(75, 23);
            this.metroButton2.TabIndex = 1;
            this.metroButton2.Text = "JOINT";
            this.metroButton2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(42, 28);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroButton1.TabIndex = 0;
            this.metroButton1.Text = "LINEA";
            this.metroButton1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // Impostazioni
            // 
            this.Impostazioni.Controls.Add(this.metroLabel18);
            this.Impostazioni.Controls.Add(this.metroLabel19);
            this.Impostazioni.Controls.Add(this.metroLabel20);
            this.Impostazioni.Controls.Add(this.metroLabel21);
            this.Impostazioni.Controls.Add(this.metroLabel22);
            this.Impostazioni.Controls.Add(this.metroLabel23);
            this.Impostazioni.Controls.Add(this.metroButton11);
            this.Impostazioni.Controls.Add(this.metroButton18);
            this.Impostazioni.Controls.Add(this.metroButton19);
            this.Impostazioni.Controls.Add(this.metroButton20);
            this.Impostazioni.Controls.Add(this.metroButton21);
            this.Impostazioni.Controls.Add(this.metroButton22);
            this.Impostazioni.Controls.Add(this.metroButton23);
            this.Impostazioni.Controls.Add(this.metroButton24);
            this.Impostazioni.Controls.Add(this.metroButton25);
            this.Impostazioni.Controls.Add(this.metroButton26);
            this.Impostazioni.Controls.Add(this.metroButton27);
            this.Impostazioni.Controls.Add(this.metroButton28);
            this.Impostazioni.HorizontalScrollbarBarColor = true;
            this.Impostazioni.HorizontalScrollbarHighlightOnWheel = false;
            this.Impostazioni.HorizontalScrollbarSize = 10;
            this.Impostazioni.Location = new System.Drawing.Point(4, 38);
            this.Impostazioni.Name = "Impostazioni";
            this.Impostazioni.Size = new System.Drawing.Size(338, 196);
            this.Impostazioni.TabIndex = 2;
            this.Impostazioni.Text = "Joint                ";
            this.Impostazioni.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Impostazioni.VerticalScrollbarBarColor = true;
            this.Impostazioni.VerticalScrollbarHighlightOnWheel = false;
            this.Impostazioni.VerticalScrollbarSize = 10;
            // 
            // metroLabel18
            // 
            this.metroLabel18.AutoSize = true;
            this.metroLabel18.Location = new System.Drawing.Point(221, 124);
            this.metroLabel18.Name = "metroLabel18";
            this.metroLabel18.Size = new System.Drawing.Size(21, 19);
            this.metroLabel18.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel18.TabIndex = 42;
            this.metroLabel18.Text = "J6";
            this.metroLabel18.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel19
            // 
            this.metroLabel19.AutoSize = true;
            this.metroLabel19.Location = new System.Drawing.Point(221, 66);
            this.metroLabel19.Name = "metroLabel19";
            this.metroLabel19.Size = new System.Drawing.Size(21, 19);
            this.metroLabel19.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel19.TabIndex = 41;
            this.metroLabel19.Text = "J5";
            this.metroLabel19.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel20
            // 
            this.metroLabel20.AutoSize = true;
            this.metroLabel20.Location = new System.Drawing.Point(221, 4);
            this.metroLabel20.Name = "metroLabel20";
            this.metroLabel20.Size = new System.Drawing.Size(21, 19);
            this.metroLabel20.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel20.TabIndex = 40;
            this.metroLabel20.Text = "J4";
            this.metroLabel20.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel21
            // 
            this.metroLabel21.AutoSize = true;
            this.metroLabel21.Location = new System.Drawing.Point(65, 124);
            this.metroLabel21.Name = "metroLabel21";
            this.metroLabel21.Size = new System.Drawing.Size(21, 19);
            this.metroLabel21.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel21.TabIndex = 39;
            this.metroLabel21.Text = "J3";
            this.metroLabel21.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel22
            // 
            this.metroLabel22.AutoSize = true;
            this.metroLabel22.Location = new System.Drawing.Point(65, 66);
            this.metroLabel22.Name = "metroLabel22";
            this.metroLabel22.Size = new System.Drawing.Size(21, 19);
            this.metroLabel22.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel22.TabIndex = 38;
            this.metroLabel22.Text = "J2";
            this.metroLabel22.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel23
            // 
            this.metroLabel23.AutoSize = true;
            this.metroLabel23.Location = new System.Drawing.Point(65, 4);
            this.metroLabel23.Name = "metroLabel23";
            this.metroLabel23.Size = new System.Drawing.Size(21, 19);
            this.metroLabel23.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel23.TabIndex = 37;
            this.metroLabel23.Text = "J1";
            this.metroLabel23.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroButton11
            // 
            this.metroButton11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton11.BackgroundImage")));
            this.metroButton11.Location = new System.Drawing.Point(186, 145);
            this.metroButton11.Name = "metroButton11";
            this.metroButton11.Size = new System.Drawing.Size(33, 33);
            this.metroButton11.TabIndex = 36;
            this.metroButton11.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton11.UseSelectable = true;
            this.metroButton11.Click += new System.EventHandler(this.metroButton11_Click_1);
            // 
            // metroButton18
            // 
            this.metroButton18.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton18.BackgroundImage")));
            this.metroButton18.Location = new System.Drawing.Point(186, 88);
            this.metroButton18.Name = "metroButton18";
            this.metroButton18.Size = new System.Drawing.Size(33, 33);
            this.metroButton18.TabIndex = 35;
            this.metroButton18.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton18.UseSelectable = true;
            this.metroButton18.Click += new System.EventHandler(this.metroButton18_Click);
            // 
            // metroButton19
            // 
            this.metroButton19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton19.BackgroundImage")));
            this.metroButton19.Location = new System.Drawing.Point(186, 26);
            this.metroButton19.Name = "metroButton19";
            this.metroButton19.Size = new System.Drawing.Size(33, 33);
            this.metroButton19.TabIndex = 34;
            this.metroButton19.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton19.UseSelectable = true;
            this.metroButton19.Click += new System.EventHandler(this.metroButton19_Click);
            // 
            // metroButton20
            // 
            this.metroButton20.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton20.BackgroundImage")));
            this.metroButton20.Location = new System.Drawing.Point(29, 145);
            this.metroButton20.Name = "metroButton20";
            this.metroButton20.Size = new System.Drawing.Size(33, 33);
            this.metroButton20.TabIndex = 33;
            this.metroButton20.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton20.UseSelectable = true;
            this.metroButton20.Click += new System.EventHandler(this.metroButton20_Click);
            // 
            // metroButton21
            // 
            this.metroButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton21.BackgroundImage")));
            this.metroButton21.Location = new System.Drawing.Point(29, 88);
            this.metroButton21.Name = "metroButton21";
            this.metroButton21.Size = new System.Drawing.Size(33, 33);
            this.metroButton21.TabIndex = 32;
            this.metroButton21.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton21.UseSelectable = true;
            this.metroButton21.Click += new System.EventHandler(this.metroButton21_Click);
            // 
            // metroButton22
            // 
            this.metroButton22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton22.BackgroundImage")));
            this.metroButton22.Location = new System.Drawing.Point(29, 26);
            this.metroButton22.Name = "metroButton22";
            this.metroButton22.Size = new System.Drawing.Size(33, 33);
            this.metroButton22.TabIndex = 31;
            this.metroButton22.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton22.UseSelectable = true;
            this.metroButton22.Click += new System.EventHandler(this.metroButton22_Click);
            // 
            // metroButton23
            // 
            this.metroButton23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton23.BackgroundImage")));
            this.metroButton23.Location = new System.Drawing.Point(238, 145);
            this.metroButton23.Name = "metroButton23";
            this.metroButton23.Size = new System.Drawing.Size(33, 33);
            this.metroButton23.TabIndex = 30;
            this.metroButton23.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton23.UseSelectable = true;
            this.metroButton23.Click += new System.EventHandler(this.metroButton23_Click);
            // 
            // metroButton24
            // 
            this.metroButton24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton24.BackgroundImage")));
            this.metroButton24.Location = new System.Drawing.Point(238, 88);
            this.metroButton24.Name = "metroButton24";
            this.metroButton24.Size = new System.Drawing.Size(33, 33);
            this.metroButton24.TabIndex = 29;
            this.metroButton24.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton24.UseSelectable = true;
            this.metroButton24.Click += new System.EventHandler(this.metroButton24_Click);
            // 
            // metroButton25
            // 
            this.metroButton25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton25.BackgroundImage")));
            this.metroButton25.Location = new System.Drawing.Point(238, 26);
            this.metroButton25.Name = "metroButton25";
            this.metroButton25.Size = new System.Drawing.Size(33, 33);
            this.metroButton25.TabIndex = 28;
            this.metroButton25.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton25.UseSelectable = true;
            this.metroButton25.Click += new System.EventHandler(this.metroButton25_Click);
            // 
            // metroButton26
            // 
            this.metroButton26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton26.BackgroundImage")));
            this.metroButton26.Location = new System.Drawing.Point(80, 145);
            this.metroButton26.Name = "metroButton26";
            this.metroButton26.Size = new System.Drawing.Size(33, 33);
            this.metroButton26.TabIndex = 27;
            this.metroButton26.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton26.UseSelectable = true;
            this.metroButton26.Click += new System.EventHandler(this.metroButton26_Click);
            // 
            // metroButton27
            // 
            this.metroButton27.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton27.BackgroundImage")));
            this.metroButton27.Location = new System.Drawing.Point(80, 88);
            this.metroButton27.Name = "metroButton27";
            this.metroButton27.Size = new System.Drawing.Size(33, 33);
            this.metroButton27.TabIndex = 26;
            this.metroButton27.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton27.UseSelectable = true;
            this.metroButton27.Click += new System.EventHandler(this.metroButton27_Click);
            // 
            // metroButton28
            // 
            this.metroButton28.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton28.BackgroundImage")));
            this.metroButton28.Location = new System.Drawing.Point(80, 26);
            this.metroButton28.Name = "metroButton28";
            this.metroButton28.Size = new System.Drawing.Size(33, 33);
            this.metroButton28.TabIndex = 25;
            this.metroButton28.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton28.UseSelectable = true;
            this.metroButton28.Click += new System.EventHandler(this.metroButton28_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "label1";
            this.label1.Visible = false;
            // 
            // metroButton10
            // 
            this.metroButton10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton10.BackgroundImage")));
            this.metroButton10.Location = new System.Drawing.Point(238, 26);
            this.metroButton10.Name = "metroButton10";
            this.metroButton10.Size = new System.Drawing.Size(33, 33);
            this.metroButton10.TabIndex = 5;
            this.metroButton10.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton10.UseSelectable = true;
            this.metroButton10.Click += new System.EventHandler(this.metroButton10_Click);
            // 
            // metroButton12
            // 
            this.metroButton12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton12.BackgroundImage")));
            this.metroButton12.Location = new System.Drawing.Point(29, 88);
            this.metroButton12.Name = "metroButton12";
            this.metroButton12.Size = new System.Drawing.Size(33, 33);
            this.metroButton12.TabIndex = 9;
            this.metroButton12.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton12.UseSelectable = true;
            this.metroButton12.Click += new System.EventHandler(this.metroButton12_Click);
            // 
            // metroButton13
            // 
            this.metroButton13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton13.BackgroundImage")));
            this.metroButton13.Location = new System.Drawing.Point(29, 145);
            this.metroButton13.Name = "metroButton13";
            this.metroButton13.Size = new System.Drawing.Size(33, 33);
            this.metroButton13.TabIndex = 10;
            this.metroButton13.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton13.UseSelectable = true;
            this.metroButton13.Click += new System.EventHandler(this.metroButton13_Click);
            // 
            // metroButton14
            // 
            this.metroButton14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton14.BackgroundImage")));
            this.metroButton14.Location = new System.Drawing.Point(186, 26);
            this.metroButton14.Name = "metroButton14";
            this.metroButton14.Size = new System.Drawing.Size(33, 33);
            this.metroButton14.TabIndex = 11;
            this.metroButton14.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton14.UseSelectable = true;
            this.metroButton14.Click += new System.EventHandler(this.metroButton14_Click);
            // 
            // metroButton15
            // 
            this.metroButton15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton15.BackgroundImage")));
            this.metroButton15.Location = new System.Drawing.Point(186, 88);
            this.metroButton15.Name = "metroButton15";
            this.metroButton15.Size = new System.Drawing.Size(33, 33);
            this.metroButton15.TabIndex = 12;
            this.metroButton15.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton15.UseSelectable = true;
            this.metroButton15.Click += new System.EventHandler(this.metroButton15_Click);
            // 
            // metroButton16
            // 
            this.metroButton16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton16.BackgroundImage")));
            this.metroButton16.Location = new System.Drawing.Point(186, 145);
            this.metroButton16.Name = "metroButton16";
            this.metroButton16.Size = new System.Drawing.Size(33, 33);
            this.metroButton16.TabIndex = 13;
            this.metroButton16.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton16.UseSelectable = true;
            this.metroButton16.Click += new System.EventHandler(this.metroButton16_Click);
            // 
            // metroButton17
            // 
            this.metroButton17.Location = new System.Drawing.Point(694, 222);
            this.metroButton17.Name = "metroButton17";
            this.metroButton17.Size = new System.Drawing.Size(77, 23);
            this.metroButton17.TabIndex = 24;
            this.metroButton17.Text = "Zero Robot";
            this.metroButton17.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton17.UseSelectable = true;
            this.metroButton17.Click += new System.EventHandler(this.metroButton17_Click);
            // 
            // metroButton29
            // 
            this.metroButton29.Location = new System.Drawing.Point(106, 815);
            this.metroButton29.Name = "metroButton29";
            this.metroButton29.Size = new System.Drawing.Size(123, 23);
            this.metroButton29.TabIndex = 5;
            this.metroButton29.Text = "Cancella istruzione";
            this.metroButton29.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton29.UseSelectable = true;
            this.metroButton29.Visible = false;
            this.metroButton29.Click += new System.EventHandler(this.metroButton29_Click_2);
            // 
            // metroButton3
            // 
            this.metroButton3.Highlight = true;
            this.metroButton3.Location = new System.Drawing.Point(306, 269);
            this.metroButton3.Name = "metroButton3";
            this.metroButton3.Size = new System.Drawing.Size(75, 23);
            this.metroButton3.Style = MetroFramework.MetroColorStyle.Green;
            this.metroButton3.TabIndex = 13;
            this.metroButton3.Text = "Start";
            this.metroButton3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton3.UseSelectable = true;
            this.metroButton3.Click += new System.EventHandler(this.metroButton3_Click);
            // 
            // metroButton30
            // 
            this.metroButton30.Location = new System.Drawing.Point(106, 844);
            this.metroButton30.Name = "metroButton30";
            this.metroButton30.Size = new System.Drawing.Size(123, 23);
            this.metroButton30.TabIndex = 6;
            this.metroButton30.Text = "Copia istruzione";
            this.metroButton30.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton30.UseSelectable = true;
            this.metroButton30.Visible = false;
            this.metroButton30.Click += new System.EventHandler(this.metroButton30_Click);
            // 
            // metroButton31
            // 
            this.metroButton31.Enabled = false;
            this.metroButton31.Location = new System.Drawing.Point(251, 844);
            this.metroButton31.Name = "metroButton31";
            this.metroButton31.Size = new System.Drawing.Size(123, 23);
            this.metroButton31.TabIndex = 7;
            this.metroButton31.Text = "Incolla Istruzione";
            this.metroButton31.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton31.UseSelectable = true;
            this.metroButton31.Visible = false;
            this.metroButton31.Click += new System.EventHandler(this.metroButton31_Click_1);
            // 
            // metroButton35
            // 
            this.metroButton35.Location = new System.Drawing.Point(251, 815);
            this.metroButton35.Name = "metroButton35";
            this.metroButton35.Size = new System.Drawing.Size(123, 23);
            this.metroButton35.TabIndex = 8;
            this.metroButton35.Text = "Modifica istruzione";
            this.metroButton35.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton35.UseSelectable = true;
            this.metroButton35.Visible = false;
            this.metroButton35.Click += new System.EventHandler(this.metroButton35_Click_1);
            // 
            // metroButton36
            // 
            this.metroButton36.Location = new System.Drawing.Point(394, 815);
            this.metroButton36.Name = "metroButton36";
            this.metroButton36.Size = new System.Drawing.Size(123, 23);
            this.metroButton36.TabIndex = 9;
            this.metroButton36.Text = "Cambia in Joint";
            this.metroButton36.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton36.UseSelectable = true;
            this.metroButton36.Visible = false;
            this.metroButton36.Click += new System.EventHandler(this.metroButton36_Click_1);
            // 
            // metroButton37
            // 
            this.metroButton37.Location = new System.Drawing.Point(394, 844);
            this.metroButton37.Name = "metroButton37";
            this.metroButton37.Size = new System.Drawing.Size(123, 23);
            this.metroButton37.TabIndex = 10;
            this.metroButton37.Text = "Cambia in Linea";
            this.metroButton37.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton37.UseSelectable = true;
            this.metroButton37.Visible = false;
            this.metroButton37.Click += new System.EventHandler(this.metroButton37_Click_1);
            // 
            // metroButton4
            // 
            this.metroButton4.Highlight = true;
            this.metroButton4.Location = new System.Drawing.Point(401, 269);
            this.metroButton4.Name = "metroButton4";
            this.metroButton4.Size = new System.Drawing.Size(75, 23);
            this.metroButton4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroButton4.TabIndex = 14;
            this.metroButton4.Text = "Stop";
            this.metroButton4.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton4.UseSelectable = true;
            this.metroButton4.Click += new System.EventHandler(this.metroButton4_Click);
            // 
            // metroButton41
            // 
            this.metroButton41.Location = new System.Drawing.Point(1456, 34);
            this.metroButton41.Name = "metroButton41";
            this.metroButton41.Size = new System.Drawing.Size(115, 23);
            this.metroButton41.TabIndex = 29;
            this.metroButton41.Text = "Nuovo Programma";
            this.metroButton41.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton41.UseSelectable = true;
            this.metroButton41.Click += new System.EventHandler(this.metroButton41_Click);
            // 
            // metroButton42
            // 
            this.metroButton42.Location = new System.Drawing.Point(1567, 34);
            this.metroButton42.Name = "metroButton42";
            this.metroButton42.Size = new System.Drawing.Size(115, 23);
            this.metroButton42.TabIndex = 30;
            this.metroButton42.Text = "Apri Programma";
            this.metroButton42.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton42.UseSelectable = true;
            this.metroButton42.Click += new System.EventHandler(this.metroButton42_Click);
            // 
            // metroButton43
            // 
            this.metroButton43.Location = new System.Drawing.Point(1675, 34);
            this.metroButton43.Name = "metroButton43";
            this.metroButton43.Size = new System.Drawing.Size(115, 23);
            this.metroButton43.TabIndex = 31;
            this.metroButton43.Text = "Salva Programma";
            this.metroButton43.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton43.UseSelectable = true;
            this.metroButton43.Click += new System.EventHandler(this.metroButton43_Click);
            // 
            // metroButton44
            // 
            this.metroButton44.Location = new System.Drawing.Point(1784, 34);
            this.metroButton44.Name = "metroButton44";
            this.metroButton44.Size = new System.Drawing.Size(106, 23);
            this.metroButton44.TabIndex = 32;
            this.metroButton44.Text = "Impostazioni";
            this.metroButton44.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton44.UseSelectable = true;
            this.metroButton44.Click += new System.EventHandler(this.metroButton44_Click);
            // 
            // metroButton45
            // 
            this.metroButton45.Location = new System.Drawing.Point(465, 178);
            this.metroButton45.Name = "metroButton45";
            this.metroButton45.Size = new System.Drawing.Size(115, 23);
            this.metroButton45.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroButton45.TabIndex = 33;
            this.metroButton45.Text = "Aggiungi Tempo";
            this.metroButton45.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton45.UseSelectable = true;
            this.metroButton45.Click += new System.EventHandler(this.metroButton45_Click);
            // 
            // metroButton46
            // 
            this.metroButton46.Location = new System.Drawing.Point(317, 178);
            this.metroButton46.Name = "metroButton46";
            this.metroButton46.Size = new System.Drawing.Size(115, 23);
            this.metroButton46.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroButton46.TabIndex = 34;
            this.metroButton46.Text = "Vai a istruzione";
            this.metroButton46.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton46.UseSelectable = true;
            this.metroButton46.Click += new System.EventHandler(this.metroButton46_Click);
            // 
            // metroButton5
            // 
            this.metroButton5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton5.BackgroundImage")));
            this.metroButton5.Location = new System.Drawing.Point(80, 26);
            this.metroButton5.Name = "metroButton5";
            this.metroButton5.Size = new System.Drawing.Size(33, 33);
            this.metroButton5.TabIndex = 2;
            this.metroButton5.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton5.UseSelectable = true;
            this.metroButton5.Click += new System.EventHandler(this.metroButton5_Click);
            // 
            // metroButton6
            // 
            this.metroButton6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton6.BackgroundImage")));
            this.metroButton6.Location = new System.Drawing.Point(80, 88);
            this.metroButton6.Name = "metroButton6";
            this.metroButton6.Size = new System.Drawing.Size(33, 33);
            this.metroButton6.TabIndex = 3;
            this.metroButton6.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton6.UseSelectable = true;
            this.metroButton6.Click += new System.EventHandler(this.metroButton6_Click);
            // 
            // metroButton7
            // 
            this.metroButton7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton7.BackgroundImage")));
            this.metroButton7.Location = new System.Drawing.Point(80, 145);
            this.metroButton7.Name = "metroButton7";
            this.metroButton7.Size = new System.Drawing.Size(33, 33);
            this.metroButton7.TabIndex = 4;
            this.metroButton7.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton7.UseSelectable = true;
            this.metroButton7.Click += new System.EventHandler(this.metroButton7_Click);
            // 
            // metroButton8
            // 
            this.metroButton8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton8.BackgroundImage")));
            this.metroButton8.Location = new System.Drawing.Point(238, 145);
            this.metroButton8.Name = "metroButton8";
            this.metroButton8.Size = new System.Drawing.Size(33, 33);
            this.metroButton8.TabIndex = 7;
            this.metroButton8.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton8.UseSelectable = true;
            this.metroButton8.Click += new System.EventHandler(this.metroButton8_Click);
            // 
            // metroButton9
            // 
            this.metroButton9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("metroButton9.BackgroundImage")));
            this.metroButton9.Location = new System.Drawing.Point(238, 88);
            this.metroButton9.Name = "metroButton9";
            this.metroButton9.Size = new System.Drawing.Size(33, 33);
            this.metroButton9.TabIndex = 6;
            this.metroButton9.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton9.UseSelectable = true;
            this.metroButton9.Click += new System.EventHandler(this.metroButton9_Click);
            // 
            // metroCheckBox1
            // 
            this.metroCheckBox1.AutoSize = true;
            this.metroCheckBox1.Location = new System.Drawing.Point(234, 272);
            this.metroCheckBox1.Name = "metroCheckBox1";
            this.metroCheckBox1.Size = new System.Drawing.Size(50, 15);
            this.metroCheckBox1.TabIndex = 28;
            this.metroCheckBox1.Text = "Loop";
            this.metroCheckBox1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroCheckBox1.UseSelectable = true;
            this.metroCheckBox1.CheckedChanged += new System.EventHandler(this.metroCheckBox1_CheckedChanged);
            // 
            // metroLabel1
            // 
            this.metroLabel1.Location = new System.Drawing.Point(151, 250);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(54, 21);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel1.TabIndex = 4;
            this.metroLabel1.Text = "Robot\r\n";
            this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(799, 134);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(18, 19);
            this.metroLabel10.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel10.TabIndex = 23;
            this.metroLabel10.Text = "C";
            this.metroLabel10.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(65, 4);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(17, 19);
            this.metroLabel11.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel11.TabIndex = 19;
            this.metroLabel11.Text = "X";
            this.metroLabel11.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.Location = new System.Drawing.Point(65, 66);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(17, 19);
            this.metroLabel12.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel12.TabIndex = 20;
            this.metroLabel12.Text = "Y";
            this.metroLabel12.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(65, 124);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(17, 19);
            this.metroLabel13.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel13.TabIndex = 21;
            this.metroLabel13.Text = "Z";
            this.metroLabel13.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(206, 5);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(46, 19);
            this.metroLabel14.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel14.TabIndex = 24;
            this.metroLabel14.Text = "Roll ψ";
            this.metroLabel14.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.Location = new System.Drawing.Point(203, 66);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(49, 19);
            this.metroLabel15.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel15.TabIndex = 24;
            this.metroLabel15.Text = "Pitch θ";
            this.metroLabel15.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.Location = new System.Drawing.Point(205, 124);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(47, 19);
            this.metroLabel16.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel16.TabIndex = 24;
            this.metroLabel16.Text = "Yaw φ";
            this.metroLabel16.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel17
            // 
            this.metroLabel17.AutoSize = true;
            this.metroLabel17.Location = new System.Drawing.Point(478, 68);
            this.metroLabel17.Name = "metroLabel17";
            this.metroLabel17.Size = new System.Drawing.Size(35, 19);
            this.metroLabel17.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel17.TabIndex = 25;
            this.metroLabel17.Text = "Step";
            this.metroLabel17.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(981, 200);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(98, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel2.TabIndex = 7;
            this.metroLabel2.Text = "  Accelerazione";
            this.metroLabel2.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel24
            // 
            this.metroLabel24.AutoSize = true;
            this.metroLabel24.Location = new System.Drawing.Point(20, 287);
            this.metroLabel24.Name = "metroLabel24";
            this.metroLabel24.Size = new System.Drawing.Size(67, 19);
            this.metroLabel24.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel24.TabIndex = 26;
            this.metroLabel24.Text = "Laterale   ";
            this.metroLabel24.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel25
            // 
            this.metroLabel25.AutoSize = true;
            this.metroLabel25.Location = new System.Drawing.Point(435, 287);
            this.metroLabel25.Name = "metroLabel25";
            this.metroLabel25.Size = new System.Drawing.Size(57, 19);
            this.metroLabel25.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel25.TabIndex = 27;
            this.metroLabel25.Text = "Frontale";
            this.metroLabel25.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel26
            // 
            this.metroLabel26.AutoSize = true;
            this.metroLabel26.Location = new System.Drawing.Point(21, 1018);
            this.metroLabel26.Name = "metroLabel26";
            this.metroLabel26.Size = new System.Drawing.Size(162, 19);
            this.metroLabel26.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel26.TabIndex = 11;
            this.metroLabel26.Text = "Developed by Luca Samar";
            this.metroLabel26.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(856, 200);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(55, 19);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel3.TabIndex = 8;
            this.metroLabel3.Text = "Velocità";
            this.metroLabel3.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel30
            // 
            this.metroLabel30.AutoSize = true;
            this.metroLabel30.Location = new System.Drawing.Point(554, 211);
            this.metroLabel30.Name = "metroLabel30";
            this.metroLabel30.Size = new System.Drawing.Size(26, 19);
            this.metroLabel30.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel30.TabIndex = 28;
            this.metroLabel30.Text = "ms";
            this.metroLabel30.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(671, 46);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(17, 19);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel5.TabIndex = 18;
            this.metroLabel5.Text = "X";
            this.metroLabel5.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(671, 90);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(17, 19);
            this.metroLabel6.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel6.TabIndex = 19;
            this.metroLabel6.Text = "Y";
            this.metroLabel6.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(671, 134);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(17, 19);
            this.metroLabel7.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel7.TabIndex = 20;
            this.metroLabel7.Text = "Z";
            this.metroLabel7.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(799, 46);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(18, 19);
            this.metroLabel8.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel8.TabIndex = 21;
            this.metroLabel8.Text = "A";
            this.metroLabel8.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(799, 90);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(17, 19);
            this.metroLabel9.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel9.TabIndex = 22;
            this.metroLabel9.Text = "B";
            this.metroLabel9.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroProgressBar1
            // 
            this.metroProgressBar1.Location = new System.Drawing.Point(139, 917);
            this.metroProgressBar1.Name = "metroProgressBar1";
            this.metroProgressBar1.Size = new System.Drawing.Size(917, 10);
            this.metroProgressBar1.TabIndex = 3;
            this.metroProgressBar1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroProgressBar1.Visible = false;
            // 
            // metroTextBox1
            // 
            // 
            // 
            // 
            this.metroTextBox1.CustomButton.Image = null;
            this.metroTextBox1.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.metroTextBox1.CustomButton.Name = "";
            this.metroTextBox1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox1.CustomButton.TabIndex = 1;
            this.metroTextBox1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox1.CustomButton.UseSelectable = true;
            this.metroTextBox1.CustomButton.Visible = false;
            this.metroTextBox1.Lines = new string[0];
            this.metroTextBox1.Location = new System.Drawing.Point(845, 222);
            this.metroTextBox1.MaxLength = 32767;
            this.metroTextBox1.Name = "metroTextBox1";
            this.metroTextBox1.PasswordChar = '\0';
            this.metroTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox1.SelectedText = "";
            this.metroTextBox1.SelectionLength = 0;
            this.metroTextBox1.SelectionStart = 0;
            this.metroTextBox1.ShortcutsEnabled = true;
            this.metroTextBox1.Size = new System.Drawing.Size(75, 23);
            this.metroTextBox1.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroTextBox1.TabIndex = 5;
            this.metroTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBox1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTextBox1.UseSelectable = true;
            this.metroTextBox1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox10
            // 
            // 
            // 
            // 
            this.metroTextBox10.CustomButton.Image = null;
            this.metroTextBox10.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.metroTextBox10.CustomButton.Name = "";
            this.metroTextBox10.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox10.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox10.CustomButton.TabIndex = 1;
            this.metroTextBox10.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox10.CustomButton.UseSelectable = true;
            this.metroTextBox10.CustomButton.Visible = false;
            this.metroTextBox10.Lines = new string[0];
            this.metroTextBox10.Location = new System.Drawing.Point(523, 68);
            this.metroTextBox10.MaxLength = 32767;
            this.metroTextBox10.Name = "metroTextBox10";
            this.metroTextBox10.PasswordChar = '\0';
            this.metroTextBox10.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox10.SelectedText = "";
            this.metroTextBox10.SelectionLength = 0;
            this.metroTextBox10.SelectionStart = 0;
            this.metroTextBox10.ShortcutsEnabled = true;
            this.metroTextBox10.Size = new System.Drawing.Size(75, 23);
            this.metroTextBox10.Style = MetroFramework.MetroColorStyle.Purple;
            this.metroTextBox10.TabIndex = 6;
            this.metroTextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBox10.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTextBox10.UseSelectable = true;
            this.metroTextBox10.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox10.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox10.TextChanged += new System.EventHandler(this.metroTextBox10_TextChanged);
            // 
            // metroTextBox11
            // 
            // 
            // 
            // 
            this.metroTextBox11.CustomButton.Image = null;
            this.metroTextBox11.CustomButton.Location = new System.Drawing.Point(61, 1);
            this.metroTextBox11.CustomButton.Name = "";
            this.metroTextBox11.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox11.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox11.CustomButton.TabIndex = 1;
            this.metroTextBox11.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox11.CustomButton.UseSelectable = true;
            this.metroTextBox11.CustomButton.Visible = false;
            this.metroTextBox11.Lines = new string[0];
            this.metroTextBox11.Location = new System.Drawing.Point(465, 211);
            this.metroTextBox11.MaxLength = 32767;
            this.metroTextBox11.Name = "metroTextBox11";
            this.metroTextBox11.PasswordChar = '\0';
            this.metroTextBox11.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox11.SelectedText = "";
            this.metroTextBox11.SelectionLength = 0;
            this.metroTextBox11.SelectionStart = 0;
            this.metroTextBox11.ShortcutsEnabled = true;
            this.metroTextBox11.Size = new System.Drawing.Size(83, 23);
            this.metroTextBox11.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroTextBox11.TabIndex = 28;
            this.metroTextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBox11.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTextBox11.UseSelectable = true;
            this.metroTextBox11.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox11.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox2
            // 
            // 
            // 
            // 
            this.metroTextBox2.CustomButton.Image = null;
            this.metroTextBox2.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.metroTextBox2.CustomButton.Name = "";
            this.metroTextBox2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox2.CustomButton.TabIndex = 1;
            this.metroTextBox2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox2.CustomButton.UseSelectable = true;
            this.metroTextBox2.CustomButton.Visible = false;
            this.metroTextBox2.Lines = new string[0];
            this.metroTextBox2.Location = new System.Drawing.Point(995, 222);
            this.metroTextBox2.MaxLength = 32767;
            this.metroTextBox2.Name = "metroTextBox2";
            this.metroTextBox2.PasswordChar = '\0';
            this.metroTextBox2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox2.SelectedText = "";
            this.metroTextBox2.SelectionLength = 0;
            this.metroTextBox2.SelectionStart = 0;
            this.metroTextBox2.ShortcutsEnabled = true;
            this.metroTextBox2.Size = new System.Drawing.Size(75, 23);
            this.metroTextBox2.TabIndex = 6;
            this.metroTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBox2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTextBox2.UseSelectable = true;
            this.metroTextBox2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox3
            // 
            // 
            // 
            // 
            this.metroTextBox3.CustomButton.Image = null;
            this.metroTextBox3.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.metroTextBox3.CustomButton.Name = "";
            this.metroTextBox3.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox3.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox3.CustomButton.TabIndex = 1;
            this.metroTextBox3.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox3.CustomButton.UseSelectable = true;
            this.metroTextBox3.CustomButton.Visible = false;
            this.metroTextBox3.Lines = new string[0];
            this.metroTextBox3.Location = new System.Drawing.Point(995, 174);
            this.metroTextBox3.MaxLength = 32767;
            this.metroTextBox3.Name = "metroTextBox3";
            this.metroTextBox3.PasswordChar = '\0';
            this.metroTextBox3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox3.SelectedText = "";
            this.metroTextBox3.SelectionLength = 0;
            this.metroTextBox3.SelectionStart = 0;
            this.metroTextBox3.ShortcutsEnabled = true;
            this.metroTextBox3.Size = new System.Drawing.Size(75, 23);
            this.metroTextBox3.Style = MetroFramework.MetroColorStyle.Orange;
            this.metroTextBox3.TabIndex = 10;
            this.metroTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBox3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTextBox3.UseSelectable = true;
            this.metroTextBox3.Visible = false;
            this.metroTextBox3.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox3.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroTextBox4
            // 
            // 
            // 
            // 
            this.metroTextBox4.CustomButton.Image = null;
            this.metroTextBox4.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.metroTextBox4.CustomButton.Name = "";
            this.metroTextBox4.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox4.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox4.CustomButton.TabIndex = 1;
            this.metroTextBox4.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox4.CustomButton.UseSelectable = true;
            this.metroTextBox4.CustomButton.Visible = false;
            this.metroTextBox4.Lines = new string[0];
            this.metroTextBox4.Location = new System.Drawing.Point(694, 46);
            this.metroTextBox4.MaxLength = 32767;
            this.metroTextBox4.Name = "metroTextBox4";
            this.metroTextBox4.PasswordChar = '\0';
            this.metroTextBox4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox4.SelectedText = "";
            this.metroTextBox4.SelectionLength = 0;
            this.metroTextBox4.SelectionStart = 0;
            this.metroTextBox4.ShortcutsEnabled = true;
            this.metroTextBox4.Size = new System.Drawing.Size(75, 23);
            this.metroTextBox4.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroTextBox4.TabIndex = 12;
            this.metroTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBox4.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTextBox4.UseSelectable = true;
            this.metroTextBox4.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox4.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox4.TextChanged += new System.EventHandler(this.metroTextBox4_TextChanged);
            this.metroTextBox4.Click += new System.EventHandler(this.metroTextBox4_Click);
            // 
            // metroTextBox5
            // 
            // 
            // 
            // 
            this.metroTextBox5.CustomButton.Image = null;
            this.metroTextBox5.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.metroTextBox5.CustomButton.Name = "";
            this.metroTextBox5.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox5.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox5.CustomButton.TabIndex = 1;
            this.metroTextBox5.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox5.CustomButton.UseSelectable = true;
            this.metroTextBox5.CustomButton.Visible = false;
            this.metroTextBox5.Lines = new string[0];
            this.metroTextBox5.Location = new System.Drawing.Point(694, 90);
            this.metroTextBox5.MaxLength = 32767;
            this.metroTextBox5.Name = "metroTextBox5";
            this.metroTextBox5.PasswordChar = '\0';
            this.metroTextBox5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox5.SelectedText = "";
            this.metroTextBox5.SelectionLength = 0;
            this.metroTextBox5.SelectionStart = 0;
            this.metroTextBox5.ShortcutsEnabled = true;
            this.metroTextBox5.Size = new System.Drawing.Size(75, 23);
            this.metroTextBox5.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroTextBox5.TabIndex = 13;
            this.metroTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBox5.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTextBox5.UseSelectable = true;
            this.metroTextBox5.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox5.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox5.TextChanged += new System.EventHandler(this.metroTextBox5_TextChanged);
            // 
            // metroTextBox6
            // 
            // 
            // 
            // 
            this.metroTextBox6.CustomButton.Image = null;
            this.metroTextBox6.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.metroTextBox6.CustomButton.Name = "";
            this.metroTextBox6.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox6.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox6.CustomButton.TabIndex = 1;
            this.metroTextBox6.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox6.CustomButton.UseSelectable = true;
            this.metroTextBox6.CustomButton.Visible = false;
            this.metroTextBox6.Lines = new string[0];
            this.metroTextBox6.Location = new System.Drawing.Point(822, 91);
            this.metroTextBox6.MaxLength = 32767;
            this.metroTextBox6.Name = "metroTextBox6";
            this.metroTextBox6.PasswordChar = '\0';
            this.metroTextBox6.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox6.SelectedText = "";
            this.metroTextBox6.SelectionLength = 0;
            this.metroTextBox6.SelectionStart = 0;
            this.metroTextBox6.ShortcutsEnabled = true;
            this.metroTextBox6.Size = new System.Drawing.Size(75, 23);
            this.metroTextBox6.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroTextBox6.TabIndex = 14;
            this.metroTextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBox6.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTextBox6.UseSelectable = true;
            this.metroTextBox6.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox6.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox6.TextChanged += new System.EventHandler(this.metroTextBox6_TextChanged);
            // 
            // metroTextBox7
            // 
            // 
            // 
            // 
            this.metroTextBox7.CustomButton.Image = null;
            this.metroTextBox7.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.metroTextBox7.CustomButton.Name = "";
            this.metroTextBox7.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox7.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox7.CustomButton.TabIndex = 1;
            this.metroTextBox7.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox7.CustomButton.UseSelectable = true;
            this.metroTextBox7.CustomButton.Visible = false;
            this.metroTextBox7.Lines = new string[0];
            this.metroTextBox7.Location = new System.Drawing.Point(822, 42);
            this.metroTextBox7.MaxLength = 32767;
            this.metroTextBox7.Name = "metroTextBox7";
            this.metroTextBox7.PasswordChar = '\0';
            this.metroTextBox7.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox7.SelectedText = "";
            this.metroTextBox7.SelectionLength = 0;
            this.metroTextBox7.SelectionStart = 0;
            this.metroTextBox7.ShortcutsEnabled = true;
            this.metroTextBox7.Size = new System.Drawing.Size(75, 23);
            this.metroTextBox7.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroTextBox7.TabIndex = 15;
            this.metroTextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBox7.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTextBox7.UseSelectable = true;
            this.metroTextBox7.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox7.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox7.TextChanged += new System.EventHandler(this.metroTextBox7_TextChanged);
            // 
            // metroTextBox8
            // 
            // 
            // 
            // 
            this.metroTextBox8.CustomButton.Image = null;
            this.metroTextBox8.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.metroTextBox8.CustomButton.Name = "";
            this.metroTextBox8.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox8.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox8.CustomButton.TabIndex = 1;
            this.metroTextBox8.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox8.CustomButton.UseSelectable = true;
            this.metroTextBox8.CustomButton.Visible = false;
            this.metroTextBox8.Lines = new string[0];
            this.metroTextBox8.Location = new System.Drawing.Point(694, 134);
            this.metroTextBox8.MaxLength = 32767;
            this.metroTextBox8.Name = "metroTextBox8";
            this.metroTextBox8.PasswordChar = '\0';
            this.metroTextBox8.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox8.SelectedText = "";
            this.metroTextBox8.SelectionLength = 0;
            this.metroTextBox8.SelectionStart = 0;
            this.metroTextBox8.ShortcutsEnabled = true;
            this.metroTextBox8.Size = new System.Drawing.Size(75, 23);
            this.metroTextBox8.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroTextBox8.TabIndex = 16;
            this.metroTextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBox8.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTextBox8.UseSelectable = true;
            this.metroTextBox8.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox8.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox8.TextChanged += new System.EventHandler(this.metroTextBox8_TextChanged);
            // 
            // metroTextBox9
            // 
            // 
            // 
            // 
            this.metroTextBox9.CustomButton.Image = null;
            this.metroTextBox9.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.metroTextBox9.CustomButton.Name = "";
            this.metroTextBox9.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox9.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox9.CustomButton.TabIndex = 1;
            this.metroTextBox9.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox9.CustomButton.UseSelectable = true;
            this.metroTextBox9.CustomButton.Visible = false;
            this.metroTextBox9.Lines = new string[0];
            this.metroTextBox9.Location = new System.Drawing.Point(822, 134);
            this.metroTextBox9.MaxLength = 32767;
            this.metroTextBox9.Name = "metroTextBox9";
            this.metroTextBox9.PasswordChar = '\0';
            this.metroTextBox9.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox9.SelectedText = "";
            this.metroTextBox9.SelectionLength = 0;
            this.metroTextBox9.SelectionStart = 0;
            this.metroTextBox9.ShortcutsEnabled = true;
            this.metroTextBox9.Size = new System.Drawing.Size(75, 23);
            this.metroTextBox9.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroTextBox9.TabIndex = 17;
            this.metroTextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBox9.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTextBox9.UseSelectable = true;
            this.metroTextBox9.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox9.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.metroTextBox9.TextChanged += new System.EventHandler(this.metroTextBox9_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(20, 309);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(385, 266);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox1_Paint);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox2.Location = new System.Drawing.Point(435, 309);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(384, 266);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox2_Paint_1);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(282, 82);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(312, 75);
            this.pictureBox3.TabIndex = 33;
            this.pictureBox3.TabStop = false;
            // 
            // Programma2
            // 
            this.Programma2.Controls.Add(this.metroLabel16);
            this.Programma2.Controls.Add(this.metroLabel15);
            this.Programma2.Controls.Add(this.metroLabel14);
            this.Programma2.Controls.Add(this.metroLabel13);
            this.Programma2.Controls.Add(this.metroLabel12);
            this.Programma2.Controls.Add(this.metroLabel11);
            this.Programma2.Controls.Add(this.metroButton16);
            this.Programma2.Controls.Add(this.metroButton15);
            this.Programma2.Controls.Add(this.metroButton14);
            this.Programma2.Controls.Add(this.metroButton13);
            this.Programma2.Controls.Add(this.metroButton12);
            this.Programma2.Controls.Add(this.ControlloX);
            this.Programma2.Controls.Add(this.metroButton8);
            this.Programma2.Controls.Add(this.metroButton9);
            this.Programma2.Controls.Add(this.metroButton10);
            this.Programma2.Controls.Add(this.metroButton7);
            this.Programma2.Controls.Add(this.metroButton6);
            this.Programma2.Controls.Add(this.metroButton5);
            this.Programma2.HorizontalScrollbarBarColor = true;
            this.Programma2.HorizontalScrollbarHighlightOnWheel = false;
            this.Programma2.HorizontalScrollbarSize = 10;
            this.Programma2.Location = new System.Drawing.Point(4, 38);
            this.Programma2.Name = "Programma2";
            this.Programma2.Size = new System.Drawing.Size(338, 196);
            this.Programma2.TabIndex = 0;
            this.Programma2.Text = "Cartesiano      ";
            this.Programma2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Programma2.VerticalScrollbarBarColor = true;
            this.Programma2.VerticalScrollbarHighlightOnWheel = false;
            this.Programma2.VerticalScrollbarSize = 10;
            // 
            // RobotEnabled
            // 
            this.RobotEnabled.AutoSize = true;
            this.RobotEnabled.Location = new System.Drawing.Point(125, 275);
            this.RobotEnabled.Name = "RobotEnabled";
            this.RobotEnabled.Size = new System.Drawing.Size(80, 17);
            this.RobotEnabled.Style = MetroFramework.MetroColorStyle.Blue;
            this.RobotEnabled.TabIndex = 2;
            this.RobotEnabled.Text = "Off";
            this.RobotEnabled.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.RobotEnabled.UseSelectable = true;
            this.RobotEnabled.CheckedChanged += new System.EventHandler(this.metroToggle1_CheckedChanged);
            // 
            // serialPort1
            // 
            this.serialPort1.PortName = "COM17";
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Location = new System.Drawing.Point(36, 63);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.elementHost2);
            this.splitContainer1.Panel1.Controls.Add(this.metroLabel25);
            this.splitContainer1.Panel1.Controls.Add(this.metroLabel24);
            this.splitContainer1.Panel1.Controls.Add(this.metroLabel17);
            this.splitContainer1.Panel1.Controls.Add(this.metroProgressBar1);
            this.splitContainer1.Panel1.Controls.Add(this.metroTextBox10);
            this.splitContainer1.Panel1.Controls.Add(this.metroButton17);
            this.splitContainer1.Panel1.Controls.Add(this.metroLabel10);
            this.splitContainer1.Panel1.Controls.Add(this.metroLabel9);
            this.splitContainer1.Panel1.Controls.Add(this.metroLabel8);
            this.splitContainer1.Panel1.Controls.Add(this.metroLabel7);
            this.splitContainer1.Panel1.Controls.Add(this.metroLabel6);
            this.splitContainer1.Panel1.Controls.Add(this.metroLabel5);
            this.splitContainer1.Panel1.Controls.Add(this.metroTextBox9);
            this.splitContainer1.Panel1.Controls.Add(this.metroTextBox8);
            this.splitContainer1.Panel1.Controls.Add(this.metroTextBox7);
            this.splitContainer1.Panel1.Controls.Add(this.metroTextBox6);
            this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
            this.splitContainer1.Panel1.Controls.Add(this.metroTextBox5);
            this.splitContainer1.Panel1.Controls.Add(this.metroTextBox4);
            this.splitContainer1.Panel1.Controls.Add(this.Tabprincipale);
            this.splitContainer1.Panel1.Controls.Add(this.pictureBox1);
            this.splitContainer1.Panel1.Controls.Add(this.pictureBox2);
            this.splitContainer1.Panel1.Controls.Add(this.metroTextBox2);
            this.splitContainer1.Panel1.Controls.Add(this.metroTextBox3);
            this.splitContainer1.Panel1.Controls.Add(this.metroTextBox1);
            this.splitContainer1.Panel1.Controls.Add(this.metroLabel3);
            this.splitContainer1.Panel1.Controls.Add(this.metroLabel2);
            this.splitContainer1.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel1_Paint);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.metroLabel4);
            this.splitContainer1.Panel2.Controls.Add(this.metroTextBox12);
            this.splitContainer1.Panel2.Controls.Add(this.pictureBox3);
            this.splitContainer1.Panel2.Controls.Add(this.Arduino);
            this.splitContainer1.Panel2.Controls.Add(this.metroLabel30);
            this.splitContainer1.Panel2.Controls.Add(this.metroButton37);
            this.splitContainer1.Panel2.Controls.Add(this.metroButton46);
            this.splitContainer1.Panel2.Controls.Add(this.metroTextBox11);
            this.splitContainer1.Panel2.Controls.Add(this.metroButton45);
            this.splitContainer1.Panel2.Controls.Add(this.metroCheckBox1);
            this.splitContainer1.Panel2.Controls.Add(this.metroButton4);
            this.splitContainer1.Panel2.Controls.Add(this.metroButton36);
            this.splitContainer1.Panel2.Controls.Add(this.dataGridView1);
            this.splitContainer1.Panel2.Controls.Add(this.metroButton35);
            this.splitContainer1.Panel2.Controls.Add(this.metroButton3);
            this.splitContainer1.Panel2.Controls.Add(this.metroButton29);
            this.splitContainer1.Panel2.Controls.Add(this.metroButton30);
            this.splitContainer1.Panel2.Controls.Add(this.RobotEnabled);
            this.splitContainer1.Panel2.Controls.Add(this.metroButton31);
            this.splitContainer1.Panel2.Controls.Add(this.metroLabel1);
            this.splitContainer1.Size = new System.Drawing.Size(1861, 952);
            this.splitContainer1.SplitterDistance = 1231;
            this.splitContainer1.TabIndex = 2;
            // 
            // elementHost2
            // 
            this.elementHost2.Location = new System.Drawing.Point(20, 292);
            this.elementHost2.Name = "elementHost2";
            this.elementHost2.Size = new System.Drawing.Size(1186, 601);
            this.elementHost2.TabIndex = 33;
            this.elementHost2.Text = "elementHost2";
            this.elementHost2.ChildChanged += new System.EventHandler<System.Windows.Forms.Integration.ChildChangedEventArgs>(this.elementHost2_ChildChanged);
            this.elementHost2.Child = this.userControl11;
            // 
            // Tabprincipale
            // 
            this.Tabprincipale.Controls.Add(this.Programma2);
            this.Tabprincipale.Controls.Add(this.Esecuzione);
            this.Tabprincipale.Controls.Add(this.Impostazioni);
            this.Tabprincipale.Location = new System.Drawing.Point(88, 19);
            this.Tabprincipale.Name = "Tabprincipale";
            this.Tabprincipale.SelectedIndex = 1;
            this.Tabprincipale.Size = new System.Drawing.Size(346, 238);
            this.Tabprincipale.TabIndex = 2;
            this.Tabprincipale.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Tabprincipale.UseSelectable = true;
            // 
            // timer1
            // 
            this.timer1.Interval = 20;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // metroTextBox12
            // 
            // 
            // 
            // 
            this.metroTextBox12.CustomButton.Image = null;
            this.metroTextBox12.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.metroTextBox12.CustomButton.Name = "";
            this.metroTextBox12.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.metroTextBox12.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroTextBox12.CustomButton.TabIndex = 1;
            this.metroTextBox12.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.metroTextBox12.CustomButton.UseSelectable = true;
            this.metroTextBox12.CustomButton.Visible = false;
            this.metroTextBox12.Lines = new string[] {
        "1"};
            this.metroTextBox12.Location = new System.Drawing.Point(336, 32);
            this.metroTextBox12.MaxLength = 32767;
            this.metroTextBox12.Name = "metroTextBox12";
            this.metroTextBox12.PasswordChar = '\0';
            this.metroTextBox12.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.metroTextBox12.SelectedText = "";
            this.metroTextBox12.SelectionLength = 0;
            this.metroTextBox12.SelectionStart = 0;
            this.metroTextBox12.ShortcutsEnabled = true;
            this.metroTextBox12.Size = new System.Drawing.Size(75, 23);
            this.metroTextBox12.Style = MetroFramework.MetroColorStyle.Lime;
            this.metroTextBox12.TabIndex = 35;
            this.metroTextBox12.Text = "1";
            this.metroTextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.metroTextBox12.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTextBox12.UseSelectable = true;
            this.metroTextBox12.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.metroTextBox12.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(328, 10);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(94, 19);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel4.TabIndex = 36;
            this.metroLabel4.Text = "linearizzazione";
            this.metroLabel4.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // Form1
            // 
            this.AccessibleDescription = "";
            this.AccessibleName = "form1";
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1920, 1080);
            this.Controls.Add(this.metroButton41);
            this.Controls.Add(this.metroLabel26);
            this.Controls.Add(this.metroButton44);
            this.Controls.Add(this.metroButton43);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.metroButton42);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation;
            this.Style = MetroFramework.MetroColorStyle.Silver;
            this.Text = "Robot Lab";
            this.TextAlign = MetroFramework.Forms.MetroFormTextAlign.Center;
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.Esecuzione.ResumeLayout(false);
            this.Esecuzione.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.Impostazioni.ResumeLayout(false);
            this.Impostazioni.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.Programma2.ResumeLayout(false);
            this.Programma2.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.Tabprincipale.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton Arduino;
        private MetroFramework.Controls.MetroButton ControlloX;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroButton metroButton10;
        private MetroFramework.Controls.MetroButton metroButton11;
        private MetroFramework.Controls.MetroButton metroButton12;
        private MetroFramework.Controls.MetroButton metroButton13;
        private MetroFramework.Controls.MetroButton metroButton14;
        private MetroFramework.Controls.MetroButton metroButton15;
        private MetroFramework.Controls.MetroButton metroButton16;
        private MetroFramework.Controls.MetroButton metroButton17;
        private MetroFramework.Controls.MetroButton metroButton18;
        private MetroFramework.Controls.MetroButton metroButton19;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroButton metroButton20;
        private MetroFramework.Controls.MetroButton metroButton21;
        private MetroFramework.Controls.MetroButton metroButton22;
        private MetroFramework.Controls.MetroButton metroButton23;
        private MetroFramework.Controls.MetroButton metroButton24;
        private MetroFramework.Controls.MetroButton metroButton25;
        private MetroFramework.Controls.MetroButton metroButton26;
        private MetroFramework.Controls.MetroButton metroButton27;
        private MetroFramework.Controls.MetroButton metroButton28;
        private MetroFramework.Controls.MetroButton metroButton29;
        private MetroFramework.Controls.MetroButton metroButton3;
        private MetroFramework.Controls.MetroButton metroButton30;
        private MetroFramework.Controls.MetroButton metroButton31;
        private MetroFramework.Controls.MetroButton metroButton32;
        private MetroFramework.Controls.MetroButton metroButton33;
        private MetroFramework.Controls.MetroButton metroButton34;
        private MetroFramework.Controls.MetroButton metroButton35;
        private MetroFramework.Controls.MetroButton metroButton36;
        private MetroFramework.Controls.MetroButton metroButton37;
        private MetroFramework.Controls.MetroButton metroButton38;
        private MetroFramework.Controls.MetroButton metroButton39;
        private MetroFramework.Controls.MetroButton metroButton4;
        private MetroFramework.Controls.MetroButton metroButton40;
        private MetroFramework.Controls.MetroButton metroButton41;
        private MetroFramework.Controls.MetroButton metroButton42;
        private MetroFramework.Controls.MetroButton metroButton43;
        private MetroFramework.Controls.MetroButton metroButton44;
        private MetroFramework.Controls.MetroButton metroButton45;
        private MetroFramework.Controls.MetroButton metroButton46;
        private MetroFramework.Controls.MetroButton metroButton5;
        private MetroFramework.Controls.MetroButton metroButton6;
        private MetroFramework.Controls.MetroButton metroButton7;
        private MetroFramework.Controls.MetroButton metroButton8;
        private MetroFramework.Controls.MetroButton metroButton9;
        private MetroFramework.Controls.MetroCheckBox metroCheckBox1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private MetroFramework.Controls.MetroLabel metroLabel17;
        private MetroFramework.Controls.MetroLabel metroLabel18;
        private MetroFramework.Controls.MetroLabel metroLabel19;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel20;
        private MetroFramework.Controls.MetroLabel metroLabel21;
        private MetroFramework.Controls.MetroLabel metroLabel22;
        private MetroFramework.Controls.MetroLabel metroLabel23;
        private MetroFramework.Controls.MetroLabel metroLabel24;
        private MetroFramework.Controls.MetroLabel metroLabel25;
        private MetroFramework.Controls.MetroLabel metroLabel26;
        private MetroFramework.Controls.MetroLabel metroLabel27;
        private MetroFramework.Controls.MetroLabel metroLabel28;
        private MetroFramework.Controls.MetroLabel metroLabel29;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel30;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroProgressBar metroProgressBar1;
        private MetroFramework.Controls.MetroTabControl Tabprincipale;
        private MetroFramework.Controls.MetroTabPage Esecuzione;
        private MetroFramework.Controls.MetroTabPage Impostazioni;
        private MetroFramework.Controls.MetroTabPage Programma2;
        private MetroFramework.Controls.MetroTextBox metroTextBox1;
        private MetroFramework.Controls.MetroTextBox metroTextBox10;
        private MetroFramework.Controls.MetroTextBox metroTextBox11;
        private MetroFramework.Controls.MetroTextBox metroTextBox2;
        private MetroFramework.Controls.MetroTextBox metroTextBox3;
        private MetroFramework.Controls.MetroTextBox metroTextBox4;
        private MetroFramework.Controls.MetroTextBox metroTextBox5;
        private MetroFramework.Controls.MetroTextBox metroTextBox6;
        private MetroFramework.Controls.MetroTextBox metroTextBox7;
        private MetroFramework.Controls.MetroTextBox metroTextBox8;
        private MetroFramework.Controls.MetroTextBox metroTextBox9;
        private MetroFramework.Controls.MetroToggle RobotEnabled;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Integration.ElementHost elementHost2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Timer timer1;
        private UserControl1 userControl11;
        public System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tool;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroTextBox metroTextBox12;
    }
}
