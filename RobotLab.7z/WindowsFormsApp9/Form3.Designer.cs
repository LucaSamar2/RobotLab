﻿namespace WindowsFormsApp9
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.Pin2 = new MetroFramework.Controls.MetroCheckBox();
            this.Pin3 = new MetroFramework.Controls.MetroCheckBox();
            this.Pin4 = new MetroFramework.Controls.MetroCheckBox();
            this.Pin5 = new MetroFramework.Controls.MetroCheckBox();
            this.Vpin1 = new MetroFramework.Controls.MetroTextBox();
            this.Vpin2 = new MetroFramework.Controls.MetroTextBox();
            this.Vpin3 = new MetroFramework.Controls.MetroTextBox();
            this.Vpin4 = new MetroFramework.Controls.MetroTextBox();
            this.Vpin5 = new MetroFramework.Controls.MetroTextBox();
            this.Pin1 = new MetroFramework.Controls.MetroCheckBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.Default = new MetroFramework.Controls.MetroLabel();
            this._default = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.OK = new MetroFramework.Controls.MetroButton();
            this.Chiudi = new MetroFramework.Controls.MetroButton();
            this.Contatore = new MetroFramework.Controls.MetroCheckBox();
            this.Vcont = new MetroFramework.Controls.MetroTextBox();
            this.Pin1DOenable = new MetroFramework.Controls.MetroToggle();
            this.Pin2DOenable = new MetroFramework.Controls.MetroToggle();
            this.Pin3DOenable = new MetroFramework.Controls.MetroToggle();
            this.Pin4DOenable = new MetroFramework.Controls.MetroToggle();
            this.Pin5DOenable = new MetroFramework.Controls.MetroToggle();
            this.DEF_DOenable = new MetroFramework.Controls.MetroToggle();
            this.P1D1 = new System.Windows.Forms.CheckBox();
            this.P1D2 = new System.Windows.Forms.CheckBox();
            this.P1D3 = new System.Windows.Forms.CheckBox();
            this.P1D4 = new System.Windows.Forms.CheckBox();
            this.P1D5 = new System.Windows.Forms.CheckBox();
            this.P2D1 = new System.Windows.Forms.CheckBox();
            this.P2D2 = new System.Windows.Forms.CheckBox();
            this.P2D3 = new System.Windows.Forms.CheckBox();
            this.P2D4 = new System.Windows.Forms.CheckBox();
            this.P2D5 = new System.Windows.Forms.CheckBox();
            this.P3D1 = new System.Windows.Forms.CheckBox();
            this.P3D2 = new System.Windows.Forms.CheckBox();
            this.P3D3 = new System.Windows.Forms.CheckBox();
            this.P3D4 = new System.Windows.Forms.CheckBox();
            this.P3D5 = new System.Windows.Forms.CheckBox();
            this.P4D1 = new System.Windows.Forms.CheckBox();
            this.P4D2 = new System.Windows.Forms.CheckBox();
            this.P4D3 = new System.Windows.Forms.CheckBox();
            this.P4D4 = new System.Windows.Forms.CheckBox();
            this.P4D5 = new System.Windows.Forms.CheckBox();
            this.P5D1 = new System.Windows.Forms.CheckBox();
            this.P5D2 = new System.Windows.Forms.CheckBox();
            this.P5D3 = new System.Windows.Forms.CheckBox();
            this.P5D4 = new System.Windows.Forms.CheckBox();
            this.P5D5 = new System.Windows.Forms.CheckBox();
            this.DEF_DO1 = new System.Windows.Forms.CheckBox();
            this.DEF_DO2 = new System.Windows.Forms.CheckBox();
            this.DEF_DO3 = new System.Windows.Forms.CheckBox();
            this.DEF_DO4 = new System.Windows.Forms.CheckBox();
            this.DEF_DO5 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // Pin2
            // 
            this.Pin2.AutoSize = true;
            this.Pin2.Location = new System.Drawing.Point(90, 137);
            this.Pin2.Name = "Pin2";
            this.Pin2.Size = new System.Drawing.Size(60, 15);
            this.Pin2.TabIndex = 1;
            this.Pin2.Text = "Input 2";
            this.Pin2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Pin2.UseSelectable = true;
            this.Pin2.CheckedChanged += new System.EventHandler(this.Pin2_CheckedChanged);
            // 
            // Pin3
            // 
            this.Pin3.AutoSize = true;
            this.Pin3.Location = new System.Drawing.Point(90, 166);
            this.Pin3.Name = "Pin3";
            this.Pin3.Size = new System.Drawing.Size(60, 15);
            this.Pin3.TabIndex = 2;
            this.Pin3.Text = "Input 3";
            this.Pin3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Pin3.UseSelectable = true;
            this.Pin3.CheckedChanged += new System.EventHandler(this.Pin3_CheckedChanged);
            // 
            // Pin4
            // 
            this.Pin4.AutoSize = true;
            this.Pin4.Location = new System.Drawing.Point(90, 194);
            this.Pin4.Name = "Pin4";
            this.Pin4.Size = new System.Drawing.Size(60, 15);
            this.Pin4.TabIndex = 3;
            this.Pin4.Text = "Input 4";
            this.Pin4.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Pin4.UseSelectable = true;
            this.Pin4.CheckedChanged += new System.EventHandler(this.Pin4_CheckedChanged);
            // 
            // Pin5
            // 
            this.Pin5.AutoSize = true;
            this.Pin5.Location = new System.Drawing.Point(90, 224);
            this.Pin5.Name = "Pin5";
            this.Pin5.Size = new System.Drawing.Size(60, 15);
            this.Pin5.TabIndex = 4;
            this.Pin5.Text = "Input 5";
            this.Pin5.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Pin5.UseSelectable = true;
            this.Pin5.CheckedChanged += new System.EventHandler(this.Pin5_CheckedChanged);
            // 
            // Vpin1
            // 
            // 
            // 
            // 
            this.Vpin1.CustomButton.Image = null;
            this.Vpin1.CustomButton.Location = new System.Drawing.Point(18, 1);
            this.Vpin1.CustomButton.Name = "";
            this.Vpin1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Vpin1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Vpin1.CustomButton.TabIndex = 1;
            this.Vpin1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Vpin1.CustomButton.UseSelectable = true;
            this.Vpin1.CustomButton.Visible = false;
            this.Vpin1.Enabled = false;
            this.Vpin1.Lines = new string[0];
            this.Vpin1.Location = new System.Drawing.Point(156, 103);
            this.Vpin1.MaxLength = 32767;
            this.Vpin1.Name = "Vpin1";
            this.Vpin1.PasswordChar = '\0';
            this.Vpin1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Vpin1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Vpin1.SelectedText = "";
            this.Vpin1.SelectionLength = 0;
            this.Vpin1.SelectionStart = 0;
            this.Vpin1.ShortcutsEnabled = true;
            this.Vpin1.Size = new System.Drawing.Size(40, 23);
            this.Vpin1.TabIndex = 5;
            this.Vpin1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Vpin1.UseSelectable = true;
            this.Vpin1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Vpin1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Vpin2
            // 
            // 
            // 
            // 
            this.Vpin2.CustomButton.Image = null;
            this.Vpin2.CustomButton.Location = new System.Drawing.Point(18, 1);
            this.Vpin2.CustomButton.Name = "";
            this.Vpin2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Vpin2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Vpin2.CustomButton.TabIndex = 1;
            this.Vpin2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Vpin2.CustomButton.UseSelectable = true;
            this.Vpin2.CustomButton.Visible = false;
            this.Vpin2.Enabled = false;
            this.Vpin2.Lines = new string[0];
            this.Vpin2.Location = new System.Drawing.Point(156, 132);
            this.Vpin2.MaxLength = 32767;
            this.Vpin2.Name = "Vpin2";
            this.Vpin2.PasswordChar = '\0';
            this.Vpin2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Vpin2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Vpin2.SelectedText = "";
            this.Vpin2.SelectionLength = 0;
            this.Vpin2.SelectionStart = 0;
            this.Vpin2.ShortcutsEnabled = true;
            this.Vpin2.Size = new System.Drawing.Size(40, 23);
            this.Vpin2.TabIndex = 6;
            this.Vpin2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Vpin2.UseSelectable = true;
            this.Vpin2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Vpin2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Vpin3
            // 
            // 
            // 
            // 
            this.Vpin3.CustomButton.Image = null;
            this.Vpin3.CustomButton.Location = new System.Drawing.Point(18, 1);
            this.Vpin3.CustomButton.Name = "";
            this.Vpin3.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Vpin3.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Vpin3.CustomButton.TabIndex = 1;
            this.Vpin3.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Vpin3.CustomButton.UseSelectable = true;
            this.Vpin3.CustomButton.Visible = false;
            this.Vpin3.Enabled = false;
            this.Vpin3.Lines = new string[0];
            this.Vpin3.Location = new System.Drawing.Point(156, 161);
            this.Vpin3.MaxLength = 32767;
            this.Vpin3.Name = "Vpin3";
            this.Vpin3.PasswordChar = '\0';
            this.Vpin3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Vpin3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Vpin3.SelectedText = "";
            this.Vpin3.SelectionLength = 0;
            this.Vpin3.SelectionStart = 0;
            this.Vpin3.ShortcutsEnabled = true;
            this.Vpin3.Size = new System.Drawing.Size(40, 23);
            this.Vpin3.TabIndex = 7;
            this.Vpin3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Vpin3.UseSelectable = true;
            this.Vpin3.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Vpin3.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Vpin4
            // 
            // 
            // 
            // 
            this.Vpin4.CustomButton.Image = null;
            this.Vpin4.CustomButton.Location = new System.Drawing.Point(18, 1);
            this.Vpin4.CustomButton.Name = "";
            this.Vpin4.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Vpin4.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Vpin4.CustomButton.TabIndex = 1;
            this.Vpin4.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Vpin4.CustomButton.UseSelectable = true;
            this.Vpin4.CustomButton.Visible = false;
            this.Vpin4.Enabled = false;
            this.Vpin4.Lines = new string[0];
            this.Vpin4.Location = new System.Drawing.Point(156, 190);
            this.Vpin4.MaxLength = 32767;
            this.Vpin4.Name = "Vpin4";
            this.Vpin4.PasswordChar = '\0';
            this.Vpin4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Vpin4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Vpin4.SelectedText = "";
            this.Vpin4.SelectionLength = 0;
            this.Vpin4.SelectionStart = 0;
            this.Vpin4.ShortcutsEnabled = true;
            this.Vpin4.Size = new System.Drawing.Size(40, 23);
            this.Vpin4.TabIndex = 8;
            this.Vpin4.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Vpin4.UseSelectable = true;
            this.Vpin4.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Vpin4.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Vpin5
            // 
            // 
            // 
            // 
            this.Vpin5.CustomButton.Image = null;
            this.Vpin5.CustomButton.Location = new System.Drawing.Point(18, 1);
            this.Vpin5.CustomButton.Name = "";
            this.Vpin5.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Vpin5.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Vpin5.CustomButton.TabIndex = 1;
            this.Vpin5.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Vpin5.CustomButton.UseSelectable = true;
            this.Vpin5.CustomButton.Visible = false;
            this.Vpin5.Enabled = false;
            this.Vpin5.Lines = new string[0];
            this.Vpin5.Location = new System.Drawing.Point(156, 219);
            this.Vpin5.MaxLength = 32767;
            this.Vpin5.Name = "Vpin5";
            this.Vpin5.PasswordChar = '\0';
            this.Vpin5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Vpin5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Vpin5.SelectedText = "";
            this.Vpin5.SelectionLength = 0;
            this.Vpin5.SelectionStart = 0;
            this.Vpin5.ShortcutsEnabled = true;
            this.Vpin5.Size = new System.Drawing.Size(40, 23);
            this.Vpin5.TabIndex = 9;
            this.Vpin5.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Vpin5.UseSelectable = true;
            this.Vpin5.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Vpin5.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Pin1
            // 
            this.Pin1.AutoSize = true;
            this.Pin1.Location = new System.Drawing.Point(90, 108);
            this.Pin1.Name = "Pin1";
            this.Pin1.Size = new System.Drawing.Size(60, 15);
            this.Pin1.TabIndex = 10;
            this.Pin1.Text = "Input 1";
            this.Pin1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Pin1.UseSelectable = true;
            this.Pin1.CheckedChanged += new System.EventHandler(this.Pin1_CheckedChanged);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(158, 81);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(38, 19);
            this.metroLabel1.TabIndex = 11;
            this.metroLabel1.Text = "Vai a";
            this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // Default
            // 
            this.Default.AutoSize = true;
            this.Default.Location = new System.Drawing.Point(100, 248);
            this.Default.Name = "Default";
            this.Default.Size = new System.Drawing.Size(50, 19);
            this.Default.TabIndex = 12;
            this.Default.Text = "Default";
            this.Default.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // _default
            // 
            // 
            // 
            // 
            this._default.CustomButton.Image = null;
            this._default.CustomButton.Location = new System.Drawing.Point(18, 1);
            this._default.CustomButton.Name = "";
            this._default.CustomButton.Size = new System.Drawing.Size(21, 21);
            this._default.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this._default.CustomButton.TabIndex = 1;
            this._default.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this._default.CustomButton.UseSelectable = true;
            this._default.CustomButton.Visible = false;
            this._default.Lines = new string[0];
            this._default.Location = new System.Drawing.Point(156, 248);
            this._default.MaxLength = 32767;
            this._default.Name = "_default";
            this._default.PasswordChar = '\0';
            this._default.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this._default.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this._default.SelectedText = "";
            this._default.SelectionLength = 0;
            this._default.SelectionStart = 0;
            this._default.ShortcutsEnabled = true;
            this._default.Size = new System.Drawing.Size(40, 23);
            this._default.TabIndex = 13;
            this._default.Theme = MetroFramework.MetroThemeStyle.Dark;
            this._default.UseSelectable = true;
            this._default.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this._default.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(297, 78);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(16, 19);
            this.metroLabel2.TabIndex = 44;
            this.metroLabel2.Text = "1";
            this.metroLabel2.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(329, 78);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(16, 19);
            this.metroLabel3.TabIndex = 45;
            this.metroLabel3.Text = "2";
            this.metroLabel3.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(361, 78);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(16, 19);
            this.metroLabel5.TabIndex = 47;
            this.metroLabel5.Text = "3";
            this.metroLabel5.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(392, 78);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(16, 19);
            this.metroLabel4.TabIndex = 48;
            this.metroLabel4.Text = "4";
            this.metroLabel4.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(425, 78);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(16, 19);
            this.metroLabel6.TabIndex = 49;
            this.metroLabel6.Text = "5";
            this.metroLabel6.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(317, 50);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(91, 19);
            this.metroLabel7.TabIndex = 50;
            this.metroLabel7.Text = "Digital Output";
            this.metroLabel7.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // OK
            // 
            this.OK.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.OK.Location = new System.Drawing.Point(158, 355);
            this.OK.Name = "OK";
            this.OK.Size = new System.Drawing.Size(102, 24);
            this.OK.TabIndex = 51;
            this.OK.Text = "OK";
            this.OK.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.OK.UseSelectable = true;
            this.OK.Click += new System.EventHandler(this.OK_Click);
            // 
            // Chiudi
            // 
            this.Chiudi.Location = new System.Drawing.Point(304, 355);
            this.Chiudi.Name = "Chiudi";
            this.Chiudi.Size = new System.Drawing.Size(103, 24);
            this.Chiudi.TabIndex = 52;
            this.Chiudi.Text = "Chiudi";
            this.Chiudi.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Chiudi.UseSelectable = true;
            this.Chiudi.Click += new System.EventHandler(this.Chiudi_Click);
            // 
            // Contatore
            // 
            this.Contatore.AutoSize = true;
            this.Contatore.Location = new System.Drawing.Point(372, 302);
            this.Contatore.Name = "Contatore";
            this.Contatore.Size = new System.Drawing.Size(76, 15);
            this.Contatore.TabIndex = 53;
            this.Contatore.Text = "Contatore";
            this.Contatore.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Contatore.UseSelectable = true;
            this.Contatore.CheckedChanged += new System.EventHandler(this.Contatore_CheckedChanged);
            // 
            // Vcont
            // 
            // 
            // 
            // 
            this.Vcont.CustomButton.Image = null;
            this.Vcont.CustomButton.Location = new System.Drawing.Point(18, 1);
            this.Vcont.CustomButton.Name = "";
            this.Vcont.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Vcont.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Vcont.CustomButton.TabIndex = 1;
            this.Vcont.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Vcont.CustomButton.UseSelectable = true;
            this.Vcont.CustomButton.Visible = false;
            this.Vcont.Enabled = false;
            this.Vcont.Lines = new string[0];
            this.Vcont.Location = new System.Drawing.Point(454, 296);
            this.Vcont.MaxLength = 32767;
            this.Vcont.Name = "Vcont";
            this.Vcont.PasswordChar = '\0';
            this.Vcont.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Vcont.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Vcont.SelectedText = "";
            this.Vcont.SelectionLength = 0;
            this.Vcont.SelectionStart = 0;
            this.Vcont.ShortcutsEnabled = true;
            this.Vcont.Size = new System.Drawing.Size(40, 23);
            this.Vcont.TabIndex = 54;
            this.Vcont.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Vcont.UseSelectable = true;
            this.Vcont.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Vcont.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Pin1DOenable
            // 
            this.Pin1DOenable.AutoSize = true;
            this.Pin1DOenable.Enabled = false;
            this.Pin1DOenable.Location = new System.Drawing.Point(202, 103);
            this.Pin1DOenable.Name = "Pin1DOenable";
            this.Pin1DOenable.Size = new System.Drawing.Size(80, 17);
            this.Pin1DOenable.TabIndex = 55;
            this.Pin1DOenable.Text = "Off";
            this.Pin1DOenable.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Pin1DOenable.UseSelectable = true;
            this.Pin1DOenable.CheckedChanged += new System.EventHandler(this.Pin1DOenable_CheckedChanged);
            // 
            // Pin2DOenable
            // 
            this.Pin2DOenable.AutoSize = true;
            this.Pin2DOenable.Enabled = false;
            this.Pin2DOenable.Location = new System.Drawing.Point(202, 134);
            this.Pin2DOenable.Name = "Pin2DOenable";
            this.Pin2DOenable.Size = new System.Drawing.Size(80, 17);
            this.Pin2DOenable.TabIndex = 56;
            this.Pin2DOenable.Text = "Off";
            this.Pin2DOenable.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Pin2DOenable.UseSelectable = true;
            this.Pin2DOenable.CheckedChanged += new System.EventHandler(this.Pin2DOenable_CheckedChanged);
            // 
            // Pin3DOenable
            // 
            this.Pin3DOenable.AutoSize = true;
            this.Pin3DOenable.Enabled = false;
            this.Pin3DOenable.Location = new System.Drawing.Point(202, 161);
            this.Pin3DOenable.Name = "Pin3DOenable";
            this.Pin3DOenable.Size = new System.Drawing.Size(80, 17);
            this.Pin3DOenable.TabIndex = 57;
            this.Pin3DOenable.Text = "Off";
            this.Pin3DOenable.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Pin3DOenable.UseSelectable = true;
            this.Pin3DOenable.CheckedChanged += new System.EventHandler(this.Pin3DOenable_CheckedChanged);
            // 
            // Pin4DOenable
            // 
            this.Pin4DOenable.AutoSize = true;
            this.Pin4DOenable.Enabled = false;
            this.Pin4DOenable.Location = new System.Drawing.Point(202, 190);
            this.Pin4DOenable.Name = "Pin4DOenable";
            this.Pin4DOenable.Size = new System.Drawing.Size(80, 17);
            this.Pin4DOenable.TabIndex = 58;
            this.Pin4DOenable.Text = "Off";
            this.Pin4DOenable.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Pin4DOenable.UseSelectable = true;
            this.Pin4DOenable.CheckedChanged += new System.EventHandler(this.Pin4DOenable_CheckedChanged);
            // 
            // Pin5DOenable
            // 
            this.Pin5DOenable.AutoSize = true;
            this.Pin5DOenable.Enabled = false;
            this.Pin5DOenable.Location = new System.Drawing.Point(202, 219);
            this.Pin5DOenable.Name = "Pin5DOenable";
            this.Pin5DOenable.Size = new System.Drawing.Size(80, 17);
            this.Pin5DOenable.TabIndex = 59;
            this.Pin5DOenable.Text = "Off";
            this.Pin5DOenable.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Pin5DOenable.UseSelectable = true;
            this.Pin5DOenable.CheckedChanged += new System.EventHandler(this.Pin5DOenable_CheckedChanged);
            // 
            // DEF_DOenable
            // 
            this.DEF_DOenable.AutoSize = true;
            this.DEF_DOenable.Location = new System.Drawing.Point(202, 248);
            this.DEF_DOenable.Name = "DEF_DOenable";
            this.DEF_DOenable.Size = new System.Drawing.Size(80, 17);
            this.DEF_DOenable.TabIndex = 60;
            this.DEF_DOenable.Text = "Off";
            this.DEF_DOenable.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.DEF_DOenable.UseSelectable = true;
            this.DEF_DOenable.CheckedChanged += new System.EventHandler(this.DEF_DOenable_CheckedChanged);
            // 
            // P1D1
            // 
            this.P1D1.AutoSize = true;
            this.P1D1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P1D1.BackgroundImage")));
            this.P1D1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P1D1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P1D1.Enabled = false;
            this.P1D1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P1D1.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P1D1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P1D1.Location = new System.Drawing.Point(297, 105);
            this.P1D1.Name = "P1D1";
            this.P1D1.Size = new System.Drawing.Size(12, 11);
            this.P1D1.TabIndex = 14;
            this.P1D1.UseVisualStyleBackColor = true;
            // 
            // P1D2
            // 
            this.P1D2.AutoSize = true;
            this.P1D2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P1D2.BackgroundImage")));
            this.P1D2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P1D2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P1D2.Enabled = false;
            this.P1D2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P1D2.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P1D2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P1D2.Location = new System.Drawing.Point(329, 105);
            this.P1D2.Name = "P1D2";
            this.P1D2.Size = new System.Drawing.Size(12, 11);
            this.P1D2.TabIndex = 15;
            this.P1D2.UseVisualStyleBackColor = true;
            // 
            // P1D3
            // 
            this.P1D3.AutoSize = true;
            this.P1D3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P1D3.BackgroundImage")));
            this.P1D3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P1D3.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P1D3.Enabled = false;
            this.P1D3.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P1D3.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P1D3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P1D3.Location = new System.Drawing.Point(361, 105);
            this.P1D3.Name = "P1D3";
            this.P1D3.Size = new System.Drawing.Size(12, 11);
            this.P1D3.TabIndex = 16;
            this.P1D3.UseVisualStyleBackColor = true;
            // 
            // P1D4
            // 
            this.P1D4.AutoSize = true;
            this.P1D4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P1D4.BackgroundImage")));
            this.P1D4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P1D4.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P1D4.Enabled = false;
            this.P1D4.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P1D4.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P1D4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P1D4.Location = new System.Drawing.Point(392, 105);
            this.P1D4.Name = "P1D4";
            this.P1D4.Size = new System.Drawing.Size(12, 11);
            this.P1D4.TabIndex = 17;
            this.P1D4.UseVisualStyleBackColor = true;
            // 
            // P1D5
            // 
            this.P1D5.AutoSize = true;
            this.P1D5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P1D5.BackgroundImage")));
            this.P1D5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P1D5.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P1D5.Enabled = false;
            this.P1D5.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P1D5.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P1D5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P1D5.Location = new System.Drawing.Point(426, 105);
            this.P1D5.Name = "P1D5";
            this.P1D5.Size = new System.Drawing.Size(12, 11);
            this.P1D5.TabIndex = 18;
            this.P1D5.UseVisualStyleBackColor = true;
            // 
            // P2D1
            // 
            this.P2D1.AutoSize = true;
            this.P2D1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P2D1.BackgroundImage")));
            this.P2D1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P2D1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P2D1.Enabled = false;
            this.P2D1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P2D1.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P2D1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P2D1.Location = new System.Drawing.Point(297, 134);
            this.P2D1.Name = "P2D1";
            this.P2D1.Size = new System.Drawing.Size(12, 11);
            this.P2D1.TabIndex = 19;
            this.P2D1.UseVisualStyleBackColor = true;
            // 
            // P2D2
            // 
            this.P2D2.AutoSize = true;
            this.P2D2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P2D2.BackgroundImage")));
            this.P2D2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P2D2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P2D2.Enabled = false;
            this.P2D2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P2D2.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P2D2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P2D2.Location = new System.Drawing.Point(329, 134);
            this.P2D2.Name = "P2D2";
            this.P2D2.Size = new System.Drawing.Size(12, 11);
            this.P2D2.TabIndex = 20;
            this.P2D2.UseVisualStyleBackColor = true;
            // 
            // P2D3
            // 
            this.P2D3.AutoSize = true;
            this.P2D3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P2D3.BackgroundImage")));
            this.P2D3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P2D3.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P2D3.Enabled = false;
            this.P2D3.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P2D3.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P2D3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P2D3.Location = new System.Drawing.Point(361, 134);
            this.P2D3.Name = "P2D3";
            this.P2D3.Size = new System.Drawing.Size(12, 11);
            this.P2D3.TabIndex = 21;
            this.P2D3.UseVisualStyleBackColor = true;
            // 
            // P2D4
            // 
            this.P2D4.AutoSize = true;
            this.P2D4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P2D4.BackgroundImage")));
            this.P2D4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P2D4.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P2D4.Enabled = false;
            this.P2D4.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P2D4.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P2D4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P2D4.Location = new System.Drawing.Point(392, 134);
            this.P2D4.Name = "P2D4";
            this.P2D4.Size = new System.Drawing.Size(12, 11);
            this.P2D4.TabIndex = 22;
            this.P2D4.UseVisualStyleBackColor = true;
            // 
            // P2D5
            // 
            this.P2D5.AutoSize = true;
            this.P2D5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P2D5.BackgroundImage")));
            this.P2D5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P2D5.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P2D5.Enabled = false;
            this.P2D5.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P2D5.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P2D5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P2D5.Location = new System.Drawing.Point(426, 134);
            this.P2D5.Name = "P2D5";
            this.P2D5.Size = new System.Drawing.Size(12, 11);
            this.P2D5.TabIndex = 23;
            this.P2D5.UseVisualStyleBackColor = true;
            // 
            // P3D1
            // 
            this.P3D1.AutoSize = true;
            this.P3D1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P3D1.BackgroundImage")));
            this.P3D1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P3D1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P3D1.Enabled = false;
            this.P3D1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P3D1.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P3D1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P3D1.Location = new System.Drawing.Point(297, 163);
            this.P3D1.Name = "P3D1";
            this.P3D1.Size = new System.Drawing.Size(12, 11);
            this.P3D1.TabIndex = 24;
            this.P3D1.UseVisualStyleBackColor = true;
            // 
            // P3D2
            // 
            this.P3D2.AutoSize = true;
            this.P3D2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P3D2.BackgroundImage")));
            this.P3D2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P3D2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P3D2.Enabled = false;
            this.P3D2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P3D2.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P3D2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P3D2.Location = new System.Drawing.Point(329, 163);
            this.P3D2.Name = "P3D2";
            this.P3D2.Size = new System.Drawing.Size(12, 11);
            this.P3D2.TabIndex = 25;
            this.P3D2.UseVisualStyleBackColor = true;
            // 
            // P3D3
            // 
            this.P3D3.AutoSize = true;
            this.P3D3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P3D3.BackgroundImage")));
            this.P3D3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P3D3.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P3D3.Enabled = false;
            this.P3D3.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P3D3.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P3D3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P3D3.Location = new System.Drawing.Point(361, 163);
            this.P3D3.Name = "P3D3";
            this.P3D3.Size = new System.Drawing.Size(12, 11);
            this.P3D3.TabIndex = 26;
            this.P3D3.UseVisualStyleBackColor = true;
            // 
            // P3D4
            // 
            this.P3D4.AutoSize = true;
            this.P3D4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P3D4.BackgroundImage")));
            this.P3D4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P3D4.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P3D4.Enabled = false;
            this.P3D4.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P3D4.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P3D4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P3D4.Location = new System.Drawing.Point(392, 163);
            this.P3D4.Name = "P3D4";
            this.P3D4.Size = new System.Drawing.Size(12, 11);
            this.P3D4.TabIndex = 27;
            this.P3D4.UseVisualStyleBackColor = true;
            // 
            // P3D5
            // 
            this.P3D5.AutoSize = true;
            this.P3D5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P3D5.BackgroundImage")));
            this.P3D5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P3D5.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P3D5.Enabled = false;
            this.P3D5.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P3D5.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P3D5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P3D5.Location = new System.Drawing.Point(426, 163);
            this.P3D5.Name = "P3D5";
            this.P3D5.Size = new System.Drawing.Size(12, 11);
            this.P3D5.TabIndex = 28;
            this.P3D5.UseVisualStyleBackColor = true;
            // 
            // P4D1
            // 
            this.P4D1.AutoSize = true;
            this.P4D1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P4D1.BackgroundImage")));
            this.P4D1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P4D1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P4D1.Enabled = false;
            this.P4D1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P4D1.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P4D1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P4D1.Location = new System.Drawing.Point(297, 192);
            this.P4D1.Name = "P4D1";
            this.P4D1.Size = new System.Drawing.Size(12, 11);
            this.P4D1.TabIndex = 29;
            this.P4D1.UseVisualStyleBackColor = true;
            // 
            // P4D2
            // 
            this.P4D2.AutoSize = true;
            this.P4D2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P4D2.BackgroundImage")));
            this.P4D2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P4D2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P4D2.Enabled = false;
            this.P4D2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P4D2.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P4D2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P4D2.Location = new System.Drawing.Point(329, 192);
            this.P4D2.Name = "P4D2";
            this.P4D2.Size = new System.Drawing.Size(12, 11);
            this.P4D2.TabIndex = 30;
            this.P4D2.UseVisualStyleBackColor = true;
            // 
            // P4D3
            // 
            this.P4D3.AutoSize = true;
            this.P4D3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P4D3.BackgroundImage")));
            this.P4D3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P4D3.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P4D3.Enabled = false;
            this.P4D3.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P4D3.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P4D3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P4D3.Location = new System.Drawing.Point(361, 192);
            this.P4D3.Name = "P4D3";
            this.P4D3.Size = new System.Drawing.Size(12, 11);
            this.P4D3.TabIndex = 31;
            this.P4D3.UseVisualStyleBackColor = true;
            // 
            // P4D4
            // 
            this.P4D4.AutoSize = true;
            this.P4D4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P4D4.BackgroundImage")));
            this.P4D4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P4D4.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P4D4.Enabled = false;
            this.P4D4.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P4D4.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P4D4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P4D4.Location = new System.Drawing.Point(392, 192);
            this.P4D4.Name = "P4D4";
            this.P4D4.Size = new System.Drawing.Size(12, 11);
            this.P4D4.TabIndex = 32;
            this.P4D4.UseVisualStyleBackColor = true;
            // 
            // P4D5
            // 
            this.P4D5.AutoSize = true;
            this.P4D5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P4D5.BackgroundImage")));
            this.P4D5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P4D5.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P4D5.Enabled = false;
            this.P4D5.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P4D5.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P4D5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P4D5.Location = new System.Drawing.Point(426, 192);
            this.P4D5.Name = "P4D5";
            this.P4D5.Size = new System.Drawing.Size(12, 11);
            this.P4D5.TabIndex = 33;
            this.P4D5.UseVisualStyleBackColor = true;
            // 
            // P5D1
            // 
            this.P5D1.AutoSize = true;
            this.P5D1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P5D1.BackgroundImage")));
            this.P5D1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P5D1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P5D1.Enabled = false;
            this.P5D1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P5D1.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P5D1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P5D1.Location = new System.Drawing.Point(297, 221);
            this.P5D1.Name = "P5D1";
            this.P5D1.Size = new System.Drawing.Size(12, 11);
            this.P5D1.TabIndex = 34;
            this.P5D1.UseVisualStyleBackColor = true;
            // 
            // P5D2
            // 
            this.P5D2.AutoSize = true;
            this.P5D2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P5D2.BackgroundImage")));
            this.P5D2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P5D2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P5D2.Enabled = false;
            this.P5D2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P5D2.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P5D2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P5D2.Location = new System.Drawing.Point(329, 221);
            this.P5D2.Name = "P5D2";
            this.P5D2.Size = new System.Drawing.Size(12, 11);
            this.P5D2.TabIndex = 35;
            this.P5D2.UseVisualStyleBackColor = true;
            // 
            // P5D3
            // 
            this.P5D3.AutoSize = true;
            this.P5D3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P5D3.BackgroundImage")));
            this.P5D3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P5D3.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P5D3.Enabled = false;
            this.P5D3.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P5D3.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P5D3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P5D3.Location = new System.Drawing.Point(361, 221);
            this.P5D3.Name = "P5D3";
            this.P5D3.Size = new System.Drawing.Size(12, 11);
            this.P5D3.TabIndex = 36;
            this.P5D3.UseVisualStyleBackColor = true;
            // 
            // P5D4
            // 
            this.P5D4.AutoSize = true;
            this.P5D4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P5D4.BackgroundImage")));
            this.P5D4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P5D4.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P5D4.Enabled = false;
            this.P5D4.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P5D4.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P5D4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P5D4.Location = new System.Drawing.Point(392, 221);
            this.P5D4.Name = "P5D4";
            this.P5D4.Size = new System.Drawing.Size(12, 11);
            this.P5D4.TabIndex = 37;
            this.P5D4.UseVisualStyleBackColor = true;
            // 
            // P5D5
            // 
            this.P5D5.AutoSize = true;
            this.P5D5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("P5D5.BackgroundImage")));
            this.P5D5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.P5D5.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.P5D5.Enabled = false;
            this.P5D5.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.P5D5.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.P5D5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.P5D5.Location = new System.Drawing.Point(426, 221);
            this.P5D5.Name = "P5D5";
            this.P5D5.Size = new System.Drawing.Size(12, 11);
            this.P5D5.TabIndex = 38;
            this.P5D5.UseVisualStyleBackColor = true;
            // 
            // DEF_DO1
            // 
            this.DEF_DO1.AutoSize = true;
            this.DEF_DO1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("DEF_DO1.BackgroundImage")));
            this.DEF_DO1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.DEF_DO1.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.DEF_DO1.Enabled = false;
            this.DEF_DO1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.DEF_DO1.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.DEF_DO1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DEF_DO1.Location = new System.Drawing.Point(297, 250);
            this.DEF_DO1.Name = "DEF_DO1";
            this.DEF_DO1.Size = new System.Drawing.Size(12, 11);
            this.DEF_DO1.TabIndex = 39;
            this.DEF_DO1.UseVisualStyleBackColor = true;
            // 
            // DEF_DO2
            // 
            this.DEF_DO2.AutoSize = true;
            this.DEF_DO2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("DEF_DO2.BackgroundImage")));
            this.DEF_DO2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.DEF_DO2.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.DEF_DO2.Enabled = false;
            this.DEF_DO2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.DEF_DO2.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.DEF_DO2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DEF_DO2.Location = new System.Drawing.Point(329, 250);
            this.DEF_DO2.Name = "DEF_DO2";
            this.DEF_DO2.Size = new System.Drawing.Size(12, 11);
            this.DEF_DO2.TabIndex = 40;
            this.DEF_DO2.UseVisualStyleBackColor = true;
            // 
            // DEF_DO3
            // 
            this.DEF_DO3.AutoSize = true;
            this.DEF_DO3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("DEF_DO3.BackgroundImage")));
            this.DEF_DO3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.DEF_DO3.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.DEF_DO3.Enabled = false;
            this.DEF_DO3.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.DEF_DO3.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.DEF_DO3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DEF_DO3.Location = new System.Drawing.Point(361, 250);
            this.DEF_DO3.Name = "DEF_DO3";
            this.DEF_DO3.Size = new System.Drawing.Size(12, 11);
            this.DEF_DO3.TabIndex = 41;
            this.DEF_DO3.UseVisualStyleBackColor = true;
            // 
            // DEF_DO4
            // 
            this.DEF_DO4.AutoSize = true;
            this.DEF_DO4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("DEF_DO4.BackgroundImage")));
            this.DEF_DO4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.DEF_DO4.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.DEF_DO4.Enabled = false;
            this.DEF_DO4.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.DEF_DO4.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.DEF_DO4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DEF_DO4.Location = new System.Drawing.Point(392, 250);
            this.DEF_DO4.Name = "DEF_DO4";
            this.DEF_DO4.Size = new System.Drawing.Size(12, 11);
            this.DEF_DO4.TabIndex = 42;
            this.DEF_DO4.UseVisualStyleBackColor = true;
            // 
            // DEF_DO5
            // 
            this.DEF_DO5.AutoSize = true;
            this.DEF_DO5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("DEF_DO5.BackgroundImage")));
            this.DEF_DO5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.DEF_DO5.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.DEF_DO5.Enabled = false;
            this.DEF_DO5.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.DEF_DO5.FlatAppearance.CheckedBackColor = System.Drawing.Color.Teal;
            this.DEF_DO5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DEF_DO5.Location = new System.Drawing.Point(426, 250);
            this.DEF_DO5.Name = "DEF_DO5";
            this.DEF_DO5.Size = new System.Drawing.Size(12, 11);
            this.DEF_DO5.TabIndex = 43;
            this.DEF_DO5.UseVisualStyleBackColor = true;
            // 
            // Form3
            // 
            this.AccessibleRole = System.Windows.Forms.AccessibleRole.Dialog;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(559, 427);
            this.ControlBox = false;
            this.Controls.Add(this.DEF_DOenable);
            this.Controls.Add(this.Pin5DOenable);
            this.Controls.Add(this.Pin4DOenable);
            this.Controls.Add(this.Pin3DOenable);
            this.Controls.Add(this.Pin2DOenable);
            this.Controls.Add(this.Pin1DOenable);
            this.Controls.Add(this.Vcont);
            this.Controls.Add(this.Contatore);
            this.Controls.Add(this.Chiudi);
            this.Controls.Add(this.OK);
            this.Controls.Add(this.metroLabel7);
            this.Controls.Add(this.metroLabel6);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.metroLabel5);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.DEF_DO5);
            this.Controls.Add(this.DEF_DO4);
            this.Controls.Add(this.DEF_DO3);
            this.Controls.Add(this.DEF_DO2);
            this.Controls.Add(this.DEF_DO1);
            this.Controls.Add(this.P5D5);
            this.Controls.Add(this.P5D4);
            this.Controls.Add(this.P5D3);
            this.Controls.Add(this.P5D2);
            this.Controls.Add(this.P5D1);
            this.Controls.Add(this.P4D5);
            this.Controls.Add(this.P4D4);
            this.Controls.Add(this.P4D3);
            this.Controls.Add(this.P4D2);
            this.Controls.Add(this.P4D1);
            this.Controls.Add(this.P3D5);
            this.Controls.Add(this.P3D4);
            this.Controls.Add(this.P3D3);
            this.Controls.Add(this.P3D2);
            this.Controls.Add(this.P3D1);
            this.Controls.Add(this.P2D5);
            this.Controls.Add(this.P2D4);
            this.Controls.Add(this.P2D3);
            this.Controls.Add(this.P2D2);
            this.Controls.Add(this.P2D1);
            this.Controls.Add(this.P1D5);
            this.Controls.Add(this.P1D4);
            this.Controls.Add(this.P1D3);
            this.Controls.Add(this.P1D2);
            this.Controls.Add(this.P1D1);
            this.Controls.Add(this._default);
            this.Controls.Add(this.Default);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.Pin1);
            this.Controls.Add(this.Vpin5);
            this.Controls.Add(this.Vpin4);
            this.Controls.Add(this.Vpin3);
            this.Controls.Add(this.Vpin2);
            this.Controls.Add(this.Vpin1);
            this.Controls.Add(this.Pin5);
            this.Controls.Add(this.Pin4);
            this.Controls.Add(this.Pin3);
            this.Controls.Add(this.Pin2);
            this.Name = "Form3";
            this.Resizable = false;
            this.Style = MetroFramework.MetroColorStyle.Silver;
            this.Text = "Vai a";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private MetroFramework.Controls.MetroCheckBox Pin2;
        private MetroFramework.Controls.MetroCheckBox Pin3;
        private MetroFramework.Controls.MetroCheckBox Pin4;
        private MetroFramework.Controls.MetroCheckBox Pin5;
        private MetroFramework.Controls.MetroTextBox Vpin1;
        private MetroFramework.Controls.MetroTextBox Vpin2;
        private MetroFramework.Controls.MetroTextBox Vpin3;
        private MetroFramework.Controls.MetroTextBox Vpin4;
        private MetroFramework.Controls.MetroTextBox Vpin5;
        private MetroFramework.Controls.MetroCheckBox Pin1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLabel Default;
        private MetroFramework.Controls.MetroTextBox _default;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroButton OK;
        private MetroFramework.Controls.MetroButton Chiudi;
        private MetroFramework.Controls.MetroCheckBox Contatore;
        private MetroFramework.Controls.MetroTextBox Vcont;
        private MetroFramework.Controls.MetroToggle Pin1DOenable;
        private MetroFramework.Controls.MetroToggle Pin2DOenable;
        private MetroFramework.Controls.MetroToggle Pin3DOenable;
        private MetroFramework.Controls.MetroToggle Pin4DOenable;
        private MetroFramework.Controls.MetroToggle Pin5DOenable;
        private MetroFramework.Controls.MetroToggle DEF_DOenable;
        private System.Windows.Forms.CheckBox P1D1;
        private System.Windows.Forms.CheckBox P1D2;
        private System.Windows.Forms.CheckBox P1D3;
        private System.Windows.Forms.CheckBox P1D4;
        private System.Windows.Forms.CheckBox P1D5;
        private System.Windows.Forms.CheckBox P2D1;
        private System.Windows.Forms.CheckBox P2D2;
        private System.Windows.Forms.CheckBox P2D3;
        private System.Windows.Forms.CheckBox P2D4;
        private System.Windows.Forms.CheckBox P2D5;
        private System.Windows.Forms.CheckBox P3D1;
        private System.Windows.Forms.CheckBox P3D2;
        private System.Windows.Forms.CheckBox P3D3;
        private System.Windows.Forms.CheckBox P3D4;
        private System.Windows.Forms.CheckBox P3D5;
        private System.Windows.Forms.CheckBox P4D1;
        private System.Windows.Forms.CheckBox P4D2;
        private System.Windows.Forms.CheckBox P4D3;
        private System.Windows.Forms.CheckBox P4D4;
        private System.Windows.Forms.CheckBox P4D5;
        private System.Windows.Forms.CheckBox P5D1;
        private System.Windows.Forms.CheckBox P5D2;
        private System.Windows.Forms.CheckBox P5D3;
        private System.Windows.Forms.CheckBox P5D4;
        private System.Windows.Forms.CheckBox P5D5;
        private System.Windows.Forms.CheckBox DEF_DO1;
        private System.Windows.Forms.CheckBox DEF_DO2;
        private System.Windows.Forms.CheckBox DEF_DO3;
        private System.Windows.Forms.CheckBox DEF_DO4;
        private System.Windows.Forms.CheckBox DEF_DO5;
    }
}