﻿namespace WindowsFormsApp9
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Limiti = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel16 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel15 = new MetroFramework.Controls.MetroLabel();
            this.Limite6min = new MetroFramework.Controls.MetroTextBox();
            this.Limite5min = new MetroFramework.Controls.MetroTextBox();
            this.Limite4min = new MetroFramework.Controls.MetroTextBox();
            this.Limite3min = new MetroFramework.Controls.MetroTextBox();
            this.Limite2min = new MetroFramework.Controls.MetroTextBox();
            this.Limite1min = new MetroFramework.Controls.MetroTextBox();
            this.Limite6max = new MetroFramework.Controls.MetroTextBox();
            this.Limite5max = new MetroFramework.Controls.MetroTextBox();
            this.Limite4max = new MetroFramework.Controls.MetroTextBox();
            this.Limite3max = new MetroFramework.Controls.MetroTextBox();
            this.Limite2max = new MetroFramework.Controls.MetroTextBox();
            this.Limite1max = new MetroFramework.Controls.MetroTextBox();
            this.LimiteAsse6 = new MetroFramework.Controls.MetroLabel();
            this.LimiteAsse5 = new MetroFramework.Controls.MetroLabel();
            this.LimiteAsse4 = new MetroFramework.Controls.MetroLabel();
            this.LimiteAsse3 = new MetroFramework.Controls.MetroLabel();
            this.LimiteAsse2 = new MetroFramework.Controls.MetroLabel();
            this.LimiteAsse1 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.Modifiche2D = new MetroFramework.Controls.MetroCheckBox();
            this.metroLabel14 = new MetroFramework.Controls.MetroLabel();
            this.Tool = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.Asta = new MetroFramework.Controls.MetroTextBox();
            this.Leva2 = new MetroFramework.Controls.MetroTextBox();
            this.Leva1 = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroTile1 = new MetroFramework.Controls.MetroTile();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.A6 = new MetroFramework.Controls.MetroTextBox();
            this.D6 = new MetroFramework.Controls.MetroTextBox();
            this.A5 = new MetroFramework.Controls.MetroTextBox();
            this.D5 = new MetroFramework.Controls.MetroTextBox();
            this.A4 = new MetroFramework.Controls.MetroTextBox();
            this.D4 = new MetroFramework.Controls.MetroTextBox();
            this.A3 = new MetroFramework.Controls.MetroTextBox();
            this.D3 = new MetroFramework.Controls.MetroTextBox();
            this.A2 = new MetroFramework.Controls.MetroTextBox();
            this.D2 = new MetroFramework.Controls.MetroTextBox();
            this.A1 = new MetroFramework.Controls.MetroTextBox();
            this.D1 = new MetroFramework.Controls.MetroTextBox();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.metroButton2 = new MetroFramework.Controls.MetroButton();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.Limiti.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            this.metroTile1.SuspendLayout();
            this.SuspendLayout();
            // 
            // Limiti
            // 
            this.Limiti.Controls.Add(this.metroTabPage1);
            this.Limiti.Controls.Add(this.metroTabPage2);
            this.Limiti.Location = new System.Drawing.Point(23, 63);
            this.Limiti.Name = "Limiti";
            this.Limiti.SelectedIndex = 1;
            this.Limiti.Size = new System.Drawing.Size(374, 310);
            this.Limiti.Style = MetroFramework.MetroColorStyle.Red;
            this.Limiti.TabIndex = 0;
            this.Limiti.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Limiti.UseSelectable = true;
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.metroLabel16);
            this.metroTabPage2.Controls.Add(this.metroLabel15);
            this.metroTabPage2.Controls.Add(this.Limite6min);
            this.metroTabPage2.Controls.Add(this.Limite5min);
            this.metroTabPage2.Controls.Add(this.Limite4min);
            this.metroTabPage2.Controls.Add(this.Limite3min);
            this.metroTabPage2.Controls.Add(this.Limite2min);
            this.metroTabPage2.Controls.Add(this.Limite1min);
            this.metroTabPage2.Controls.Add(this.Limite6max);
            this.metroTabPage2.Controls.Add(this.Limite5max);
            this.metroTabPage2.Controls.Add(this.Limite4max);
            this.metroTabPage2.Controls.Add(this.Limite3max);
            this.metroTabPage2.Controls.Add(this.Limite2max);
            this.metroTabPage2.Controls.Add(this.Limite1max);
            this.metroTabPage2.Controls.Add(this.LimiteAsse6);
            this.metroTabPage2.Controls.Add(this.LimiteAsse5);
            this.metroTabPage2.Controls.Add(this.LimiteAsse4);
            this.metroTabPage2.Controls.Add(this.LimiteAsse3);
            this.metroTabPage2.Controls.Add(this.LimiteAsse2);
            this.metroTabPage2.Controls.Add(this.LimiteAsse1);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 10;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(366, 268);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "Limiti                                 ";
            this.metroTabPage2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 10;
            this.metroTabPage2.Click += new System.EventHandler(this.metroTabPage2_Click);
            // 
            // metroLabel16
            // 
            this.metroLabel16.AutoSize = true;
            this.metroLabel16.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.metroLabel16.Location = new System.Drawing.Point(208, 26);
            this.metroLabel16.Name = "metroLabel16";
            this.metroLabel16.Size = new System.Drawing.Size(41, 25);
            this.metroLabel16.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel16.TabIndex = 21;
            this.metroLabel16.Text = "Min";
            this.metroLabel16.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel15
            // 
            this.metroLabel15.AutoSize = true;
            this.metroLabel15.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel15.ForeColor = System.Drawing.SystemColors.ControlText;
            this.metroLabel15.Location = new System.Drawing.Point(129, 26);
            this.metroLabel15.Name = "metroLabel15";
            this.metroLabel15.Size = new System.Drawing.Size(44, 25);
            this.metroLabel15.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroLabel15.TabIndex = 20;
            this.metroLabel15.Text = "Max";
            this.metroLabel15.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // Limite6min
            // 
            // 
            // 
            // 
            this.Limite6min.CustomButton.Image = null;
            this.Limite6min.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.Limite6min.CustomButton.Name = "";
            this.Limite6min.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Limite6min.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Limite6min.CustomButton.TabIndex = 1;
            this.Limite6min.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Limite6min.CustomButton.UseSelectable = true;
            this.Limite6min.CustomButton.Visible = false;
            this.Limite6min.Lines = new string[] {
        "0"};
            this.Limite6min.Location = new System.Drawing.Point(189, 200);
            this.Limite6min.MaxLength = 32767;
            this.Limite6min.Name = "Limite6min";
            this.Limite6min.PasswordChar = '\0';
            this.Limite6min.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Limite6min.SelectedText = "";
            this.Limite6min.SelectionLength = 0;
            this.Limite6min.SelectionStart = 0;
            this.Limite6min.ShortcutsEnabled = true;
            this.Limite6min.Size = new System.Drawing.Size(75, 23);
            this.Limite6min.Style = MetroFramework.MetroColorStyle.Red;
            this.Limite6min.TabIndex = 19;
            this.Limite6min.Text = "0";
            this.Limite6min.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Limite6min.UseSelectable = true;
            this.Limite6min.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Limite6min.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Limite5min
            // 
            // 
            // 
            // 
            this.Limite5min.CustomButton.Image = null;
            this.Limite5min.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.Limite5min.CustomButton.Name = "";
            this.Limite5min.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Limite5min.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Limite5min.CustomButton.TabIndex = 1;
            this.Limite5min.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Limite5min.CustomButton.UseSelectable = true;
            this.Limite5min.CustomButton.Visible = false;
            this.Limite5min.Lines = new string[] {
        "0"};
            this.Limite5min.Location = new System.Drawing.Point(189, 171);
            this.Limite5min.MaxLength = 32767;
            this.Limite5min.Name = "Limite5min";
            this.Limite5min.PasswordChar = '\0';
            this.Limite5min.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Limite5min.SelectedText = "";
            this.Limite5min.SelectionLength = 0;
            this.Limite5min.SelectionStart = 0;
            this.Limite5min.ShortcutsEnabled = true;
            this.Limite5min.Size = new System.Drawing.Size(75, 23);
            this.Limite5min.Style = MetroFramework.MetroColorStyle.Red;
            this.Limite5min.TabIndex = 18;
            this.Limite5min.Text = "0";
            this.Limite5min.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Limite5min.UseSelectable = true;
            this.Limite5min.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Limite5min.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Limite4min
            // 
            // 
            // 
            // 
            this.Limite4min.CustomButton.Image = null;
            this.Limite4min.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.Limite4min.CustomButton.Name = "";
            this.Limite4min.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Limite4min.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Limite4min.CustomButton.TabIndex = 1;
            this.Limite4min.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Limite4min.CustomButton.UseSelectable = true;
            this.Limite4min.CustomButton.Visible = false;
            this.Limite4min.Lines = new string[] {
        "0"};
            this.Limite4min.Location = new System.Drawing.Point(189, 142);
            this.Limite4min.MaxLength = 32767;
            this.Limite4min.Name = "Limite4min";
            this.Limite4min.PasswordChar = '\0';
            this.Limite4min.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Limite4min.SelectedText = "";
            this.Limite4min.SelectionLength = 0;
            this.Limite4min.SelectionStart = 0;
            this.Limite4min.ShortcutsEnabled = true;
            this.Limite4min.Size = new System.Drawing.Size(75, 23);
            this.Limite4min.Style = MetroFramework.MetroColorStyle.Red;
            this.Limite4min.TabIndex = 17;
            this.Limite4min.Text = "0";
            this.Limite4min.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Limite4min.UseSelectable = true;
            this.Limite4min.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Limite4min.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Limite3min
            // 
            // 
            // 
            // 
            this.Limite3min.CustomButton.Image = null;
            this.Limite3min.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.Limite3min.CustomButton.Name = "";
            this.Limite3min.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Limite3min.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Limite3min.CustomButton.TabIndex = 1;
            this.Limite3min.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Limite3min.CustomButton.UseSelectable = true;
            this.Limite3min.CustomButton.Visible = false;
            this.Limite3min.Lines = new string[] {
        "0"};
            this.Limite3min.Location = new System.Drawing.Point(189, 113);
            this.Limite3min.MaxLength = 32767;
            this.Limite3min.Name = "Limite3min";
            this.Limite3min.PasswordChar = '\0';
            this.Limite3min.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Limite3min.SelectedText = "";
            this.Limite3min.SelectionLength = 0;
            this.Limite3min.SelectionStart = 0;
            this.Limite3min.ShortcutsEnabled = true;
            this.Limite3min.Size = new System.Drawing.Size(75, 23);
            this.Limite3min.Style = MetroFramework.MetroColorStyle.Red;
            this.Limite3min.TabIndex = 16;
            this.Limite3min.Text = "0";
            this.Limite3min.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Limite3min.UseSelectable = true;
            this.Limite3min.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Limite3min.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Limite2min
            // 
            // 
            // 
            // 
            this.Limite2min.CustomButton.Image = null;
            this.Limite2min.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.Limite2min.CustomButton.Name = "";
            this.Limite2min.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Limite2min.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Limite2min.CustomButton.TabIndex = 1;
            this.Limite2min.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Limite2min.CustomButton.UseSelectable = true;
            this.Limite2min.CustomButton.Visible = false;
            this.Limite2min.Lines = new string[] {
        "0"};
            this.Limite2min.Location = new System.Drawing.Point(189, 84);
            this.Limite2min.MaxLength = 32767;
            this.Limite2min.Name = "Limite2min";
            this.Limite2min.PasswordChar = '\0';
            this.Limite2min.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Limite2min.SelectedText = "";
            this.Limite2min.SelectionLength = 0;
            this.Limite2min.SelectionStart = 0;
            this.Limite2min.ShortcutsEnabled = true;
            this.Limite2min.Size = new System.Drawing.Size(75, 23);
            this.Limite2min.Style = MetroFramework.MetroColorStyle.Red;
            this.Limite2min.TabIndex = 15;
            this.Limite2min.Text = "0";
            this.Limite2min.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Limite2min.UseSelectable = true;
            this.Limite2min.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Limite2min.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Limite1min
            // 
            // 
            // 
            // 
            this.Limite1min.CustomButton.Image = null;
            this.Limite1min.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.Limite1min.CustomButton.Name = "";
            this.Limite1min.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Limite1min.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Limite1min.CustomButton.TabIndex = 1;
            this.Limite1min.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Limite1min.CustomButton.UseSelectable = true;
            this.Limite1min.CustomButton.Visible = false;
            this.Limite1min.Lines = new string[] {
        "0"};
            this.Limite1min.Location = new System.Drawing.Point(189, 54);
            this.Limite1min.MaxLength = 32767;
            this.Limite1min.Name = "Limite1min";
            this.Limite1min.PasswordChar = '\0';
            this.Limite1min.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Limite1min.SelectedText = "";
            this.Limite1min.SelectionLength = 0;
            this.Limite1min.SelectionStart = 0;
            this.Limite1min.ShortcutsEnabled = true;
            this.Limite1min.Size = new System.Drawing.Size(75, 23);
            this.Limite1min.Style = MetroFramework.MetroColorStyle.Red;
            this.Limite1min.TabIndex = 14;
            this.Limite1min.Text = "0";
            this.Limite1min.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Limite1min.UseSelectable = true;
            this.Limite1min.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Limite1min.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Limite6max
            // 
            // 
            // 
            // 
            this.Limite6max.CustomButton.Image = null;
            this.Limite6max.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.Limite6max.CustomButton.Name = "";
            this.Limite6max.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Limite6max.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Limite6max.CustomButton.TabIndex = 1;
            this.Limite6max.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Limite6max.CustomButton.UseSelectable = true;
            this.Limite6max.CustomButton.Visible = false;
            this.Limite6max.Lines = new string[] {
        "180"};
            this.Limite6max.Location = new System.Drawing.Point(108, 200);
            this.Limite6max.MaxLength = 32767;
            this.Limite6max.Name = "Limite6max";
            this.Limite6max.PasswordChar = '\0';
            this.Limite6max.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Limite6max.SelectedText = "";
            this.Limite6max.SelectionLength = 0;
            this.Limite6max.SelectionStart = 0;
            this.Limite6max.ShortcutsEnabled = true;
            this.Limite6max.Size = new System.Drawing.Size(75, 23);
            this.Limite6max.Style = MetroFramework.MetroColorStyle.Red;
            this.Limite6max.TabIndex = 13;
            this.Limite6max.Text = "180";
            this.Limite6max.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Limite6max.UseSelectable = true;
            this.Limite6max.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Limite6max.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Limite5max
            // 
            // 
            // 
            // 
            this.Limite5max.CustomButton.Image = null;
            this.Limite5max.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.Limite5max.CustomButton.Name = "";
            this.Limite5max.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Limite5max.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Limite5max.CustomButton.TabIndex = 1;
            this.Limite5max.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Limite5max.CustomButton.UseSelectable = true;
            this.Limite5max.CustomButton.Visible = false;
            this.Limite5max.Lines = new string[] {
        "180"};
            this.Limite5max.Location = new System.Drawing.Point(108, 171);
            this.Limite5max.MaxLength = 32767;
            this.Limite5max.Name = "Limite5max";
            this.Limite5max.PasswordChar = '\0';
            this.Limite5max.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Limite5max.SelectedText = "";
            this.Limite5max.SelectionLength = 0;
            this.Limite5max.SelectionStart = 0;
            this.Limite5max.ShortcutsEnabled = true;
            this.Limite5max.Size = new System.Drawing.Size(75, 23);
            this.Limite5max.Style = MetroFramework.MetroColorStyle.Red;
            this.Limite5max.TabIndex = 12;
            this.Limite5max.Text = "180";
            this.Limite5max.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Limite5max.UseSelectable = true;
            this.Limite5max.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Limite5max.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Limite4max
            // 
            // 
            // 
            // 
            this.Limite4max.CustomButton.Image = null;
            this.Limite4max.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.Limite4max.CustomButton.Name = "";
            this.Limite4max.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Limite4max.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Limite4max.CustomButton.TabIndex = 1;
            this.Limite4max.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Limite4max.CustomButton.UseSelectable = true;
            this.Limite4max.CustomButton.Visible = false;
            this.Limite4max.Lines = new string[] {
        "180"};
            this.Limite4max.Location = new System.Drawing.Point(108, 142);
            this.Limite4max.MaxLength = 32767;
            this.Limite4max.Name = "Limite4max";
            this.Limite4max.PasswordChar = '\0';
            this.Limite4max.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Limite4max.SelectedText = "";
            this.Limite4max.SelectionLength = 0;
            this.Limite4max.SelectionStart = 0;
            this.Limite4max.ShortcutsEnabled = true;
            this.Limite4max.Size = new System.Drawing.Size(75, 23);
            this.Limite4max.Style = MetroFramework.MetroColorStyle.Red;
            this.Limite4max.TabIndex = 11;
            this.Limite4max.Text = "180";
            this.Limite4max.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Limite4max.UseSelectable = true;
            this.Limite4max.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Limite4max.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Limite3max
            // 
            // 
            // 
            // 
            this.Limite3max.CustomButton.Image = null;
            this.Limite3max.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.Limite3max.CustomButton.Name = "";
            this.Limite3max.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Limite3max.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Limite3max.CustomButton.TabIndex = 1;
            this.Limite3max.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Limite3max.CustomButton.UseSelectable = true;
            this.Limite3max.CustomButton.Visible = false;
            this.Limite3max.Lines = new string[] {
        "180"};
            this.Limite3max.Location = new System.Drawing.Point(108, 113);
            this.Limite3max.MaxLength = 32767;
            this.Limite3max.Name = "Limite3max";
            this.Limite3max.PasswordChar = '\0';
            this.Limite3max.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Limite3max.SelectedText = "";
            this.Limite3max.SelectionLength = 0;
            this.Limite3max.SelectionStart = 0;
            this.Limite3max.ShortcutsEnabled = true;
            this.Limite3max.Size = new System.Drawing.Size(75, 23);
            this.Limite3max.Style = MetroFramework.MetroColorStyle.Red;
            this.Limite3max.TabIndex = 10;
            this.Limite3max.Text = "180";
            this.Limite3max.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Limite3max.UseSelectable = true;
            this.Limite3max.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Limite3max.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Limite2max
            // 
            // 
            // 
            // 
            this.Limite2max.CustomButton.Image = null;
            this.Limite2max.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.Limite2max.CustomButton.Name = "";
            this.Limite2max.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Limite2max.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Limite2max.CustomButton.TabIndex = 1;
            this.Limite2max.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Limite2max.CustomButton.UseSelectable = true;
            this.Limite2max.CustomButton.Visible = false;
            this.Limite2max.Lines = new string[] {
        "180"};
            this.Limite2max.Location = new System.Drawing.Point(108, 84);
            this.Limite2max.MaxLength = 32767;
            this.Limite2max.Name = "Limite2max";
            this.Limite2max.PasswordChar = '\0';
            this.Limite2max.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Limite2max.SelectedText = "";
            this.Limite2max.SelectionLength = 0;
            this.Limite2max.SelectionStart = 0;
            this.Limite2max.ShortcutsEnabled = true;
            this.Limite2max.Size = new System.Drawing.Size(75, 23);
            this.Limite2max.Style = MetroFramework.MetroColorStyle.Red;
            this.Limite2max.TabIndex = 9;
            this.Limite2max.Text = "180";
            this.Limite2max.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Limite2max.UseSelectable = true;
            this.Limite2max.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Limite2max.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Limite1max
            // 
            // 
            // 
            // 
            this.Limite1max.CustomButton.Image = null;
            this.Limite1max.CustomButton.Location = new System.Drawing.Point(53, 1);
            this.Limite1max.CustomButton.Name = "";
            this.Limite1max.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Limite1max.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Limite1max.CustomButton.TabIndex = 1;
            this.Limite1max.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Limite1max.CustomButton.UseSelectable = true;
            this.Limite1max.CustomButton.Visible = false;
            this.Limite1max.Lines = new string[] {
        "180"};
            this.Limite1max.Location = new System.Drawing.Point(108, 54);
            this.Limite1max.MaxLength = 32767;
            this.Limite1max.Name = "Limite1max";
            this.Limite1max.PasswordChar = '\0';
            this.Limite1max.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Limite1max.SelectedText = "";
            this.Limite1max.SelectionLength = 0;
            this.Limite1max.SelectionStart = 0;
            this.Limite1max.ShortcutsEnabled = true;
            this.Limite1max.Size = new System.Drawing.Size(75, 23);
            this.Limite1max.Style = MetroFramework.MetroColorStyle.Red;
            this.Limite1max.TabIndex = 8;
            this.Limite1max.Text = "180";
            this.Limite1max.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Limite1max.UseSelectable = true;
            this.Limite1max.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Limite1max.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // LimiteAsse6
            // 
            this.LimiteAsse6.AutoSize = true;
            this.LimiteAsse6.Location = new System.Drawing.Point(56, 200);
            this.LimiteAsse6.Name = "LimiteAsse6";
            this.LimiteAsse6.Size = new System.Drawing.Size(46, 19);
            this.LimiteAsse6.TabIndex = 7;
            this.LimiteAsse6.Text = "Asse 6";
            this.LimiteAsse6.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // LimiteAsse5
            // 
            this.LimiteAsse5.AutoSize = true;
            this.LimiteAsse5.Location = new System.Drawing.Point(56, 171);
            this.LimiteAsse5.Name = "LimiteAsse5";
            this.LimiteAsse5.Size = new System.Drawing.Size(46, 19);
            this.LimiteAsse5.TabIndex = 6;
            this.LimiteAsse5.Text = "Asse 5";
            this.LimiteAsse5.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // LimiteAsse4
            // 
            this.LimiteAsse4.AutoSize = true;
            this.LimiteAsse4.Location = new System.Drawing.Point(56, 143);
            this.LimiteAsse4.Name = "LimiteAsse4";
            this.LimiteAsse4.Size = new System.Drawing.Size(46, 19);
            this.LimiteAsse4.TabIndex = 5;
            this.LimiteAsse4.Text = "Asse 4";
            this.LimiteAsse4.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // LimiteAsse3
            // 
            this.LimiteAsse3.AutoSize = true;
            this.LimiteAsse3.Location = new System.Drawing.Point(56, 113);
            this.LimiteAsse3.Name = "LimiteAsse3";
            this.LimiteAsse3.Size = new System.Drawing.Size(46, 19);
            this.LimiteAsse3.TabIndex = 4;
            this.LimiteAsse3.Text = "Asse 3";
            this.LimiteAsse3.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // LimiteAsse2
            // 
            this.LimiteAsse2.AutoSize = true;
            this.LimiteAsse2.Location = new System.Drawing.Point(56, 84);
            this.LimiteAsse2.Name = "LimiteAsse2";
            this.LimiteAsse2.Size = new System.Drawing.Size(46, 19);
            this.LimiteAsse2.TabIndex = 3;
            this.LimiteAsse2.Text = "Asse 2";
            this.LimiteAsse2.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // LimiteAsse1
            // 
            this.LimiteAsse1.AutoSize = true;
            this.LimiteAsse1.Location = new System.Drawing.Point(56, 54);
            this.LimiteAsse1.Name = "LimiteAsse1";
            this.LimiteAsse1.Size = new System.Drawing.Size(46, 19);
            this.LimiteAsse1.TabIndex = 2;
            this.LimiteAsse1.Text = "Asse 1";
            this.LimiteAsse1.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.Controls.Add(this.Modifiche2D);
            this.metroTabPage1.Controls.Add(this.metroLabel14);
            this.metroTabPage1.Controls.Add(this.Tool);
            this.metroTabPage1.Controls.Add(this.metroLabel12);
            this.metroTabPage1.Controls.Add(this.metroLabel11);
            this.metroTabPage1.Controls.Add(this.metroLabel10);
            this.metroTabPage1.Controls.Add(this.Asta);
            this.metroTabPage1.Controls.Add(this.Leva2);
            this.metroTabPage1.Controls.Add(this.Leva1);
            this.metroTabPage1.Controls.Add(this.metroLabel9);
            this.metroTabPage1.Controls.Add(this.metroLabel8);
            this.metroTabPage1.Controls.Add(this.metroLabel7);
            this.metroTabPage1.Controls.Add(this.metroLabel6);
            this.metroTabPage1.Controls.Add(this.metroLabel5);
            this.metroTabPage1.Controls.Add(this.metroLabel1);
            this.metroTabPage1.Controls.Add(this.metroLabel3);
            this.metroTabPage1.Controls.Add(this.metroTile1);
            this.metroTabPage1.Controls.Add(this.A6);
            this.metroTabPage1.Controls.Add(this.D6);
            this.metroTabPage1.Controls.Add(this.A5);
            this.metroTabPage1.Controls.Add(this.D5);
            this.metroTabPage1.Controls.Add(this.A4);
            this.metroTabPage1.Controls.Add(this.D4);
            this.metroTabPage1.Controls.Add(this.A3);
            this.metroTabPage1.Controls.Add(this.D3);
            this.metroTabPage1.Controls.Add(this.A2);
            this.metroTabPage1.Controls.Add(this.D2);
            this.metroTabPage1.Controls.Add(this.A1);
            this.metroTabPage1.Controls.Add(this.D1);
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 10;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(366, 268);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "Modello Matematico              ";
            this.metroTabPage1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 10;
            // 
            // Modifiche2D
            // 
            this.Modifiche2D.AutoSize = true;
            this.Modifiche2D.Location = new System.Drawing.Point(45, 229);
            this.Modifiche2D.Name = "Modifiche2D";
            this.Modifiche2D.Size = new System.Drawing.Size(179, 15);
            this.Modifiche2D.Style = MetroFramework.MetroColorStyle.Red;
            this.Modifiche2D.TabIndex = 32;
            this.Modifiche2D.Text = "Abilita modifiche (visione 2D)";
            this.Modifiche2D.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Modifiche2D.UseSelectable = true;
            this.Modifiche2D.CheckedChanged += new System.EventHandler(this.Modifiche2D_CheckedChanged);
            // 
            // metroLabel14
            // 
            this.metroLabel14.AutoSize = true;
            this.metroLabel14.Location = new System.Drawing.Point(235, 181);
            this.metroLabel14.Name = "metroLabel14";
            this.metroLabel14.Size = new System.Drawing.Size(35, 19);
            this.metroLabel14.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel14.TabIndex = 31;
            this.metroLabel14.Text = "Tool";
            this.metroLabel14.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel14.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // Tool
            // 
            // 
            // 
            // 
            this.Tool.CustomButton.Image = null;
            this.Tool.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.Tool.CustomButton.Name = "";
            this.Tool.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Tool.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Tool.CustomButton.TabIndex = 1;
            this.Tool.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Tool.CustomButton.UseSelectable = true;
            this.Tool.CustomButton.Visible = false;
            this.Tool.Lines = new string[0];
            this.Tool.Location = new System.Drawing.Point(276, 181);
            this.Tool.MaxLength = 32767;
            this.Tool.Name = "Tool";
            this.Tool.PasswordChar = '\0';
            this.Tool.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Tool.SelectedText = "";
            this.Tool.SelectionLength = 0;
            this.Tool.SelectionStart = 0;
            this.Tool.ShortcutsEnabled = true;
            this.Tool.Size = new System.Drawing.Size(66, 23);
            this.Tool.Style = MetroFramework.MetroColorStyle.Red;
            this.Tool.TabIndex = 30;
            this.Tool.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Tool.UseSelectable = true;
            this.Tool.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Tool.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.Location = new System.Drawing.Point(236, 142);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(34, 19);
            this.metroLabel12.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel12.TabIndex = 29;
            this.metroLabel12.Text = "Asta";
            this.metroLabel12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel12.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(224, 102);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(46, 19);
            this.metroLabel11.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel11.TabIndex = 28;
            this.metroLabel11.Text = "Leva 2";
            this.metroLabel11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel11.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.Location = new System.Drawing.Point(224, 60);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(46, 19);
            this.metroLabel10.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel10.TabIndex = 27;
            this.metroLabel10.Text = "Leva 1";
            this.metroLabel10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel10.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // Asta
            // 
            // 
            // 
            // 
            this.Asta.CustomButton.Image = null;
            this.Asta.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.Asta.CustomButton.Name = "";
            this.Asta.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Asta.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Asta.CustomButton.TabIndex = 1;
            this.Asta.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Asta.CustomButton.UseSelectable = true;
            this.Asta.CustomButton.Visible = false;
            this.Asta.Enabled = false;
            this.Asta.Lines = new string[0];
            this.Asta.Location = new System.Drawing.Point(276, 142);
            this.Asta.MaxLength = 32767;
            this.Asta.Name = "Asta";
            this.Asta.PasswordChar = '\0';
            this.Asta.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Asta.SelectedText = "";
            this.Asta.SelectionLength = 0;
            this.Asta.SelectionStart = 0;
            this.Asta.ShortcutsEnabled = true;
            this.Asta.Size = new System.Drawing.Size(66, 23);
            this.Asta.Style = MetroFramework.MetroColorStyle.Red;
            this.Asta.TabIndex = 26;
            this.Asta.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Asta.UseSelectable = true;
            this.Asta.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Asta.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Leva2
            // 
            // 
            // 
            // 
            this.Leva2.CustomButton.Image = null;
            this.Leva2.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.Leva2.CustomButton.Name = "";
            this.Leva2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Leva2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Leva2.CustomButton.TabIndex = 1;
            this.Leva2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Leva2.CustomButton.UseSelectable = true;
            this.Leva2.CustomButton.Visible = false;
            this.Leva2.Enabled = false;
            this.Leva2.Lines = new string[0];
            this.Leva2.Location = new System.Drawing.Point(276, 102);
            this.Leva2.MaxLength = 32767;
            this.Leva2.Name = "Leva2";
            this.Leva2.PasswordChar = '\0';
            this.Leva2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Leva2.SelectedText = "";
            this.Leva2.SelectionLength = 0;
            this.Leva2.SelectionStart = 0;
            this.Leva2.ShortcutsEnabled = true;
            this.Leva2.Size = new System.Drawing.Size(66, 23);
            this.Leva2.Style = MetroFramework.MetroColorStyle.Red;
            this.Leva2.TabIndex = 25;
            this.Leva2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Leva2.UseSelectable = true;
            this.Leva2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Leva2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // Leva1
            // 
            // 
            // 
            // 
            this.Leva1.CustomButton.Image = null;
            this.Leva1.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.Leva1.CustomButton.Name = "";
            this.Leva1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.Leva1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.Leva1.CustomButton.TabIndex = 1;
            this.Leva1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.Leva1.CustomButton.UseSelectable = true;
            this.Leva1.CustomButton.Visible = false;
            this.Leva1.Enabled = false;
            this.Leva1.Lines = new string[0];
            this.Leva1.Location = new System.Drawing.Point(276, 58);
            this.Leva1.MaxLength = 32767;
            this.Leva1.Name = "Leva1";
            this.Leva1.PasswordChar = '\0';
            this.Leva1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.Leva1.SelectedText = "";
            this.Leva1.SelectionLength = 0;
            this.Leva1.SelectionStart = 0;
            this.Leva1.ShortcutsEnabled = true;
            this.Leva1.Size = new System.Drawing.Size(66, 23);
            this.Leva1.Style = MetroFramework.MetroColorStyle.Red;
            this.Leva1.TabIndex = 24;
            this.Leva1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Leva1.UseSelectable = true;
            this.Leva1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.Leva1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.Location = new System.Drawing.Point(23, 181);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(16, 19);
            this.metroLabel9.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel9.TabIndex = 23;
            this.metroLabel9.Text = "6";
            this.metroLabel9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel9.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.Location = new System.Drawing.Point(23, 161);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(16, 19);
            this.metroLabel8.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel8.TabIndex = 22;
            this.metroLabel8.Text = "5";
            this.metroLabel8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel8.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.Location = new System.Drawing.Point(23, 142);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(16, 19);
            this.metroLabel7.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel7.TabIndex = 21;
            this.metroLabel7.Text = "4";
            this.metroLabel7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel7.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.Location = new System.Drawing.Point(23, 123);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(16, 19);
            this.metroLabel6.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel6.TabIndex = 20;
            this.metroLabel6.Text = "3";
            this.metroLabel6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel6.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.Location = new System.Drawing.Point(23, 106);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(16, 19);
            this.metroLabel5.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel5.TabIndex = 19;
            this.metroLabel5.Text = "2";
            this.metroLabel5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel5.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 86);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(16, 19);
            this.metroLabel1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel1.TabIndex = 0;
            this.metroLabel1.Text = "1";
            this.metroLabel1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel1.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(23, 22);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(185, 19);
            this.metroLabel3.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel3.TabIndex = 18;
            this.metroLabel3.Text = "Parametri Denavit Hartenberg";
            this.metroLabel3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel3.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroTile1
            // 
            this.metroTile1.ActiveControl = null;
            this.metroTile1.Controls.Add(this.metroLabel2);
            this.metroTile1.Controls.Add(this.metroLabel4);
            this.metroTile1.Location = new System.Drawing.Point(45, 58);
            this.metroTile1.Name = "metroTile1";
            this.metroTile1.Size = new System.Drawing.Size(129, 23);
            this.metroTile1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroTile1.TabIndex = 15;
            this.metroTile1.Text = "D";
            this.metroTile1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroTile1.UseSelectable = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(63, 2);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(42, 19);
            this.metroLabel2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel2.TabIndex = 17;
            this.metroLabel2.Text = "      A";
            this.metroLabel2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel2.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(3, 2);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(42, 19);
            this.metroLabel4.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel4.TabIndex = 19;
            this.metroLabel4.Text = "      D";
            this.metroLabel4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel4.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // A6
            // 
            // 
            // 
            // 
            this.A6.CustomButton.Image = null;
            this.A6.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.A6.CustomButton.Name = "";
            this.A6.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.A6.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.A6.CustomButton.TabIndex = 1;
            this.A6.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.A6.CustomButton.UseSelectable = true;
            this.A6.CustomButton.Visible = false;
            this.A6.Enabled = false;
            this.A6.Lines = new string[0];
            this.A6.Location = new System.Drawing.Point(108, 181);
            this.A6.MaxLength = 32767;
            this.A6.Name = "A6";
            this.A6.PasswordChar = '\0';
            this.A6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.A6.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.A6.SelectedText = "";
            this.A6.SelectionLength = 0;
            this.A6.SelectionStart = 0;
            this.A6.ShortcutsEnabled = true;
            this.A6.Size = new System.Drawing.Size(66, 23);
            this.A6.Style = MetroFramework.MetroColorStyle.Silver;
            this.A6.TabIndex = 14;
            this.A6.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.A6.UseSelectable = true;
            this.A6.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.A6.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // D6
            // 
            // 
            // 
            // 
            this.D6.CustomButton.Image = null;
            this.D6.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.D6.CustomButton.Name = "";
            this.D6.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.D6.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.D6.CustomButton.TabIndex = 1;
            this.D6.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.D6.CustomButton.UseSelectable = true;
            this.D6.CustomButton.Visible = false;
            this.D6.Enabled = false;
            this.D6.Lines = new string[0];
            this.D6.Location = new System.Drawing.Point(45, 181);
            this.D6.MaxLength = 32767;
            this.D6.Name = "D6";
            this.D6.PasswordChar = '\0';
            this.D6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.D6.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.D6.SelectedText = "";
            this.D6.SelectionLength = 0;
            this.D6.SelectionStart = 0;
            this.D6.ShortcutsEnabled = true;
            this.D6.Size = new System.Drawing.Size(66, 23);
            this.D6.Style = MetroFramework.MetroColorStyle.Silver;
            this.D6.TabIndex = 13;
            this.D6.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.D6.UseSelectable = true;
            this.D6.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.D6.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // A5
            // 
            // 
            // 
            // 
            this.A5.CustomButton.Image = null;
            this.A5.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.A5.CustomButton.Name = "";
            this.A5.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.A5.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.A5.CustomButton.TabIndex = 1;
            this.A5.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.A5.CustomButton.UseSelectable = true;
            this.A5.CustomButton.Visible = false;
            this.A5.Enabled = false;
            this.A5.Lines = new string[0];
            this.A5.Location = new System.Drawing.Point(108, 161);
            this.A5.MaxLength = 32767;
            this.A5.Name = "A5";
            this.A5.PasswordChar = '\0';
            this.A5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.A5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.A5.SelectedText = "";
            this.A5.SelectionLength = 0;
            this.A5.SelectionStart = 0;
            this.A5.ShortcutsEnabled = true;
            this.A5.Size = new System.Drawing.Size(66, 23);
            this.A5.Style = MetroFramework.MetroColorStyle.Silver;
            this.A5.TabIndex = 12;
            this.A5.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.A5.UseSelectable = true;
            this.A5.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.A5.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // D5
            // 
            // 
            // 
            // 
            this.D5.CustomButton.Image = null;
            this.D5.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.D5.CustomButton.Name = "";
            this.D5.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.D5.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.D5.CustomButton.TabIndex = 1;
            this.D5.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.D5.CustomButton.UseSelectable = true;
            this.D5.CustomButton.Visible = false;
            this.D5.Enabled = false;
            this.D5.Lines = new string[0];
            this.D5.Location = new System.Drawing.Point(45, 161);
            this.D5.MaxLength = 32767;
            this.D5.Name = "D5";
            this.D5.PasswordChar = '\0';
            this.D5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.D5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.D5.SelectedText = "";
            this.D5.SelectionLength = 0;
            this.D5.SelectionStart = 0;
            this.D5.ShortcutsEnabled = true;
            this.D5.Size = new System.Drawing.Size(66, 23);
            this.D5.Style = MetroFramework.MetroColorStyle.Silver;
            this.D5.TabIndex = 11;
            this.D5.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.D5.UseSelectable = true;
            this.D5.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.D5.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // A4
            // 
            // 
            // 
            // 
            this.A4.CustomButton.Image = null;
            this.A4.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.A4.CustomButton.Name = "";
            this.A4.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.A4.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.A4.CustomButton.TabIndex = 1;
            this.A4.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.A4.CustomButton.UseSelectable = true;
            this.A4.CustomButton.Visible = false;
            this.A4.Enabled = false;
            this.A4.Lines = new string[0];
            this.A4.Location = new System.Drawing.Point(108, 142);
            this.A4.MaxLength = 32767;
            this.A4.Name = "A4";
            this.A4.PasswordChar = '\0';
            this.A4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.A4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.A4.SelectedText = "";
            this.A4.SelectionLength = 0;
            this.A4.SelectionStart = 0;
            this.A4.ShortcutsEnabled = true;
            this.A4.Size = new System.Drawing.Size(66, 23);
            this.A4.Style = MetroFramework.MetroColorStyle.Silver;
            this.A4.TabIndex = 10;
            this.A4.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.A4.UseSelectable = true;
            this.A4.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.A4.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // D4
            // 
            // 
            // 
            // 
            this.D4.CustomButton.Image = null;
            this.D4.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.D4.CustomButton.Name = "";
            this.D4.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.D4.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.D4.CustomButton.TabIndex = 1;
            this.D4.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.D4.CustomButton.UseSelectable = true;
            this.D4.CustomButton.Visible = false;
            this.D4.Enabled = false;
            this.D4.Lines = new string[0];
            this.D4.Location = new System.Drawing.Point(45, 142);
            this.D4.MaxLength = 32767;
            this.D4.Name = "D4";
            this.D4.PasswordChar = '\0';
            this.D4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.D4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.D4.SelectedText = "";
            this.D4.SelectionLength = 0;
            this.D4.SelectionStart = 0;
            this.D4.ShortcutsEnabled = true;
            this.D4.Size = new System.Drawing.Size(66, 23);
            this.D4.Style = MetroFramework.MetroColorStyle.Silver;
            this.D4.TabIndex = 9;
            this.D4.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.D4.UseSelectable = true;
            this.D4.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.D4.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // A3
            // 
            // 
            // 
            // 
            this.A3.CustomButton.Image = null;
            this.A3.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.A3.CustomButton.Name = "";
            this.A3.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.A3.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.A3.CustomButton.TabIndex = 1;
            this.A3.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.A3.CustomButton.UseSelectable = true;
            this.A3.CustomButton.Visible = false;
            this.A3.Enabled = false;
            this.A3.Lines = new string[0];
            this.A3.Location = new System.Drawing.Point(108, 122);
            this.A3.MaxLength = 32767;
            this.A3.Name = "A3";
            this.A3.PasswordChar = '\0';
            this.A3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.A3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.A3.SelectedText = "";
            this.A3.SelectionLength = 0;
            this.A3.SelectionStart = 0;
            this.A3.ShortcutsEnabled = true;
            this.A3.Size = new System.Drawing.Size(66, 23);
            this.A3.Style = MetroFramework.MetroColorStyle.Silver;
            this.A3.TabIndex = 8;
            this.A3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.A3.UseSelectable = true;
            this.A3.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.A3.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // D3
            // 
            // 
            // 
            // 
            this.D3.CustomButton.Image = null;
            this.D3.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.D3.CustomButton.Name = "";
            this.D3.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.D3.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.D3.CustomButton.TabIndex = 1;
            this.D3.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.D3.CustomButton.UseSelectable = true;
            this.D3.CustomButton.Visible = false;
            this.D3.Enabled = false;
            this.D3.Lines = new string[0];
            this.D3.Location = new System.Drawing.Point(45, 122);
            this.D3.MaxLength = 32767;
            this.D3.Name = "D3";
            this.D3.PasswordChar = '\0';
            this.D3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.D3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.D3.SelectedText = "";
            this.D3.SelectionLength = 0;
            this.D3.SelectionStart = 0;
            this.D3.ShortcutsEnabled = true;
            this.D3.Size = new System.Drawing.Size(66, 23);
            this.D3.Style = MetroFramework.MetroColorStyle.Silver;
            this.D3.TabIndex = 7;
            this.D3.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.D3.UseSelectable = true;
            this.D3.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.D3.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // A2
            // 
            // 
            // 
            // 
            this.A2.CustomButton.Image = null;
            this.A2.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.A2.CustomButton.Name = "";
            this.A2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.A2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.A2.CustomButton.TabIndex = 1;
            this.A2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.A2.CustomButton.UseSelectable = true;
            this.A2.CustomButton.Visible = false;
            this.A2.Enabled = false;
            this.A2.Lines = new string[0];
            this.A2.Location = new System.Drawing.Point(108, 102);
            this.A2.MaxLength = 32767;
            this.A2.Name = "A2";
            this.A2.PasswordChar = '\0';
            this.A2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.A2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.A2.SelectedText = "";
            this.A2.SelectionLength = 0;
            this.A2.SelectionStart = 0;
            this.A2.ShortcutsEnabled = true;
            this.A2.Size = new System.Drawing.Size(66, 23);
            this.A2.Style = MetroFramework.MetroColorStyle.Silver;
            this.A2.TabIndex = 6;
            this.A2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.A2.UseSelectable = true;
            this.A2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.A2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // D2
            // 
            // 
            // 
            // 
            this.D2.CustomButton.Image = null;
            this.D2.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.D2.CustomButton.Name = "";
            this.D2.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.D2.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.D2.CustomButton.TabIndex = 1;
            this.D2.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.D2.CustomButton.UseSelectable = true;
            this.D2.CustomButton.Visible = false;
            this.D2.Enabled = false;
            this.D2.Lines = new string[0];
            this.D2.Location = new System.Drawing.Point(45, 102);
            this.D2.MaxLength = 32767;
            this.D2.Name = "D2";
            this.D2.PasswordChar = '\0';
            this.D2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.D2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.D2.SelectedText = "";
            this.D2.SelectionLength = 0;
            this.D2.SelectionStart = 0;
            this.D2.ShortcutsEnabled = true;
            this.D2.Size = new System.Drawing.Size(66, 23);
            this.D2.Style = MetroFramework.MetroColorStyle.Silver;
            this.D2.TabIndex = 5;
            this.D2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.D2.UseSelectable = true;
            this.D2.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.D2.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // A1
            // 
            // 
            // 
            // 
            this.A1.CustomButton.Image = null;
            this.A1.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.A1.CustomButton.Name = "";
            this.A1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.A1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.A1.CustomButton.TabIndex = 1;
            this.A1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.A1.CustomButton.UseSelectable = true;
            this.A1.CustomButton.Visible = false;
            this.A1.Enabled = false;
            this.A1.Lines = new string[0];
            this.A1.Location = new System.Drawing.Point(108, 82);
            this.A1.MaxLength = 32767;
            this.A1.Name = "A1";
            this.A1.PasswordChar = '\0';
            this.A1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.A1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.A1.SelectedText = "";
            this.A1.SelectionLength = 0;
            this.A1.SelectionStart = 0;
            this.A1.ShortcutsEnabled = true;
            this.A1.Size = new System.Drawing.Size(66, 23);
            this.A1.Style = MetroFramework.MetroColorStyle.Silver;
            this.A1.TabIndex = 2;
            this.A1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.A1.UseSelectable = true;
            this.A1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.A1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // D1
            // 
            // 
            // 
            // 
            this.D1.CustomButton.Image = null;
            this.D1.CustomButton.Location = new System.Drawing.Point(44, 1);
            this.D1.CustomButton.Name = "";
            this.D1.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.D1.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.D1.CustomButton.TabIndex = 1;
            this.D1.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.D1.CustomButton.UseSelectable = true;
            this.D1.CustomButton.Visible = false;
            this.D1.Enabled = false;
            this.D1.Lines = new string[0];
            this.D1.Location = new System.Drawing.Point(45, 82);
            this.D1.MaxLength = 32767;
            this.D1.Name = "D1";
            this.D1.PasswordChar = '\0';
            this.D1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.D1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.D1.SelectedText = "";
            this.D1.SelectionLength = 0;
            this.D1.SelectionStart = 0;
            this.D1.ShortcutsEnabled = true;
            this.D1.Size = new System.Drawing.Size(66, 23);
            this.D1.Style = MetroFramework.MetroColorStyle.Silver;
            this.D1.TabIndex = 1;
            this.D1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.D1.UseSelectable = true;
            this.D1.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.D1.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroButton1
            // 
            this.metroButton1.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.metroButton1.Location = new System.Drawing.Point(83, 375);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(102, 23);
            this.metroButton1.Style = MetroFramework.MetroColorStyle.Red;
            this.metroButton1.TabIndex = 1;
            this.metroButton1.Text = "OK";
            this.metroButton1.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // metroButton2
            // 
            this.metroButton2.Location = new System.Drawing.Point(236, 375);
            this.metroButton2.Name = "metroButton2";
            this.metroButton2.Size = new System.Drawing.Size(102, 23);
            this.metroButton2.Style = MetroFramework.MetroColorStyle.Red;
            this.metroButton2.TabIndex = 2;
            this.metroButton2.Text = "Chiudi";
            this.metroButton2.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.metroButton2.UseSelectable = true;
            this.metroButton2.Click += new System.EventHandler(this.metroButton2_Click);
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.Location = new System.Drawing.Point(281, 21);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(59, 19);
            this.metroLabel13.Style = MetroFramework.MetroColorStyle.Red;
            this.metroLabel13.TabIndex = 28;
            this.metroLabel13.Text = "COM 17";
            this.metroLabel13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.metroLabel13.Theme = MetroFramework.MetroThemeStyle.Dark;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(373, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 29;
            this.label1.Text = "label1";
            this.label1.Visible = false;
            // 
            // Form2
            // 
            this.AccessibleRole = System.Windows.Forms.AccessibleRole.Dialog;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = MetroFramework.Forms.MetroFormBorderStyle.FixedSingle;
            this.ClientSize = new System.Drawing.Size(431, 415);
            this.ControlBox = false;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.metroLabel13);
            this.Controls.Add(this.metroButton2);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.Limiti);
            this.Name = "Form2";
            this.Resizable = false;
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.None;
            this.Style = MetroFramework.MetroColorStyle.Red;
            this.Text = "Impostazioni";
            this.Theme = MetroFramework.MetroThemeStyle.Dark;
            this.Load += new System.EventHandler(this.Form2_Load);
            this.Limiti.ResumeLayout(false);
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage2.PerformLayout();
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            this.metroTile1.ResumeLayout(false);
            this.metroTile1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl Limiti;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroTile metroTile1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox A6;
        private MetroFramework.Controls.MetroTextBox D6;
        private MetroFramework.Controls.MetroTextBox A5;
        private MetroFramework.Controls.MetroTextBox D5;
        private MetroFramework.Controls.MetroTextBox A4;
        private MetroFramework.Controls.MetroTextBox D4;
        private MetroFramework.Controls.MetroTextBox A3;
        private MetroFramework.Controls.MetroTextBox D3;
        private MetroFramework.Controls.MetroTextBox A2;
        private MetroFramework.Controls.MetroTextBox D2;
        private MetroFramework.Controls.MetroTextBox A1;
        private MetroFramework.Controls.MetroTextBox D1;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroButton metroButton1;
        private MetroFramework.Controls.MetroButton metroButton2;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroTextBox Asta;
        private MetroFramework.Controls.MetroTextBox Leva2;
        private MetroFramework.Controls.MetroTextBox Leva1;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private System.Windows.Forms.Label label1;
        private MetroFramework.Controls.MetroLabel metroLabel14;
        private MetroFramework.Controls.MetroTextBox Tool;
        private MetroFramework.Controls.MetroCheckBox Modifiche2D;
        private MetroFramework.Controls.MetroLabel metroLabel16;
        private MetroFramework.Controls.MetroLabel metroLabel15;
        private MetroFramework.Controls.MetroTextBox Limite6min;
        private MetroFramework.Controls.MetroTextBox Limite5min;
        private MetroFramework.Controls.MetroTextBox Limite4min;
        private MetroFramework.Controls.MetroTextBox Limite3min;
        private MetroFramework.Controls.MetroTextBox Limite2min;
        private MetroFramework.Controls.MetroTextBox Limite1min;
        private MetroFramework.Controls.MetroTextBox Limite6max;
        private MetroFramework.Controls.MetroTextBox Limite5max;
        private MetroFramework.Controls.MetroTextBox Limite4max;
        private MetroFramework.Controls.MetroTextBox Limite3max;
        private MetroFramework.Controls.MetroTextBox Limite2max;
        private MetroFramework.Controls.MetroTextBox Limite1max;
        private MetroFramework.Controls.MetroLabel LimiteAsse6;
        private MetroFramework.Controls.MetroLabel LimiteAsse5;
        private MetroFramework.Controls.MetroLabel LimiteAsse4;
        private MetroFramework.Controls.MetroLabel LimiteAsse3;
        private MetroFramework.Controls.MetroLabel LimiteAsse2;
        private MetroFramework.Controls.MetroLabel LimiteAsse1;
    }
}